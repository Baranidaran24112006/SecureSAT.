"""Fast CPU unit checks for raster rendering, preprocessing and export."""
import unittest

import numpy as np
import rasterio
import torch
from rasterio.transform import from_origin

from backend.services.raster import export_geotiff, read_raster, sha256, to_display


def fixture_tiff(array=None):
    array = np.zeros((13, 256, 256), dtype=np.uint16) if array is None else array
    profile = {"driver": "GTiff", "height": 256, "width": 256, "count": 13, "dtype": "uint16",
               "crs": "EPSG:32643", "transform": from_origin(500000, 2000000, 10, 10)}
    with rasterio.MemoryFile() as mem:
        with mem.open(**profile) as ds:
            ds.write(array)
        return mem.read()


class RasterTests(unittest.TestCase):
    def test_training_rgb_preprocessing(self):
        source = np.zeros((13, 256, 256), dtype=np.uint16)
        source[3] = 10000  # red = 1.0 reflectance
        source[2] = 5000   # green = 0.5
        source[1] = 2500   # blue = 0.25
        rgb, profile, invalid = read_raster(fixture_tiff(source))
        tensor = torch.from_numpy(rgb * 2 - 1)
        self.assertTrue(np.allclose(tensor[:, 0, 0].numpy(), [1.0, 0.0, -0.5]))
        self.assertEqual(profile["count"], 13)
        self.assertFalse(invalid.any())

    def test_display_preserves_rgb_and_constant_images(self):
        rgb = np.zeros((3, 256, 256), np.float32)
        rgb[0] = 1.0
        rendered, label = to_display(rgb)
        self.assertEqual(tuple(rendered[0, 0]), (255, 0, 0))
        self.assertIn("Shared", label)
        constant, _ = to_display(np.ones((3, 256, 256), np.float32) * 0.4, "percentile")
        self.assertTrue(np.all(constant == 102))

    def test_input_referenced_band_stretch_is_shared(self):
        source = np.zeros((3, 256, 256), np.float32)
        source[0] = np.linspace(0.1, 0.4, 256, dtype=np.float32)[None, :]
        source[1] = np.linspace(0.2, 0.6, 256, dtype=np.float32)[:, None]
        source[2] = np.linspace(0.05, 0.25, 256, dtype=np.float32)[None, :]
        input_image, policy = to_display(source, "input")
        joint_reference = np.concatenate((source, source * 0.5), axis=1)
        shared_input, _ = to_display(source, "input", reference=joint_reference)
        output_image, joint_policy = to_display(source.copy(), "input", reference=joint_reference)
        self.assertTrue(np.array_equal(shared_input, output_image))
        self.assertFalse(np.array_equal(input_image, shared_input))
        self.assertIn("shared", policy.lower())
        self.assertIn("Joint input/output", joint_policy)

    def test_nonfinite_and_invalid_stretch_rejected(self):
        rgb = np.zeros((3, 256, 256), np.float32)
        rgb[0, 0, 0] = np.nan
        with self.assertRaises(ValueError):
            to_display(rgb)
        with self.assertRaises(ValueError):
            to_display(np.zeros((3, 2, 2), np.float32), "unknown")

    def test_geotiff_metadata_and_hash(self):
        _, profile, _ = read_raster(fixture_tiff())
        output = export_geotiff(np.ones((3, 256, 256), np.float32) * 0.5, profile)
        with rasterio.MemoryFile(output) as mem:
            with mem.open() as ds:
                self.assertEqual(ds.count, 3)
                self.assertEqual(ds.dtypes[0], "uint16")
                self.assertEqual(ds.crs.to_string(), "EPSG:32643")
                self.assertEqual(ds.transform, from_origin(500000, 2000000, 10, 10))
                self.assertEqual(ds.descriptions, ("Red", "Green", "Blue"))
                self.assertEqual(int(ds.read(1)[0, 0]), 5000)
        self.assertEqual(len(sha256(output)), 64)
        self.assertNotEqual(sha256(output), sha256(output + b"x"))

    def test_bad_file_rejected(self):
        with self.assertRaises(ValueError):
            read_raster(b"not a tiff")


if __name__ == "__main__":
    unittest.main()
