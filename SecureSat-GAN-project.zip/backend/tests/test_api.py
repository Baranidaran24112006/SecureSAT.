"""API contract checks, including one genuine saved-checkpoint CPU inference."""
import asyncio
import base64
import io
import tempfile
import unittest
import rasterio
from fastapi import HTTPException, UploadFile
from PIL import Image

from backend.main import IntegrityRequest, SAMPLES, health, model_status, restore, samples, validate, verify_integrity
from backend.services.raster import sha256
from backend.services import model


def upload_file(name: str, data: bytes) -> UploadFile:
    stream = tempfile.SpooledTemporaryFile(max_size=64 * 1024 * 1024 + 1)
    stream.write(data)
    stream.seek(0)
    return UploadFile(filename=name, file=stream)


class ApiTests(unittest.TestCase):
    def test_health_model_and_samples_are_actual(self):
        self.assertEqual(health()["status"], "ok")
        status = model_status()
        self.assertTrue(status["checkpoint_available"])
        self.assertEqual(status["checkpoint"], "generator_reflectance_best.pth")
        self.assertGreater(len(samples()["samples"]), 0)

    def test_sha_verification(self):
        expected = "a" * 64
        result = verify_integrity(IntegrityRequest(sha256=expected, expected_sha256=expected))
        self.assertTrue(result["matches_expected"])
        changed = verify_integrity(IntegrityRequest(sha256="b" * 64, expected_sha256=expected))
        self.assertFalse(changed["matches_expected"])
        self.assertIsNone(verify_integrity(IntegrityRequest(sha256=expected))["matches_expected"])

    def test_valid_geotiff_upload_returns_preview_metadata(self):
        name = samples()["samples"][0]["name"]
        result = asyncio.run(validate(upload_file(name, (SAMPLES / name).read_bytes()), stretch="input"))
        self.assertEqual((result["width"], result["height"]), (256, 256))
        self.assertEqual(result["bands"], 13)
        self.assertTrue(result["preview"].startswith("data:image/png;base64,"))
        self.assertEqual(result["stretch"], "Input-referenced per-band 2–98 stretch (shared)")

    def test_real_checkpoint_runs_on_a_local_sample(self):
        entries = samples()["samples"]
        sample_name = next(entry["name"] for entry in entries if entry["has_reference"])
        result = asyncio.run(restore(file=None, sample=sample_name, stretch="input"))
        self.assertEqual(result["name"], sample_name)
        self.assertGreaterEqual(result["elapsed_seconds"], 0.0)
        self.assertIsNotNone(result["reference_metrics"])
        self.assertIn("Joint input/output", result["stretch"])
        self.assertEqual(len(result["input_sha256"]), 64)
        exported = base64.b64decode(result["geotiff_base64"])
        self.assertEqual(sha256(exported), result["output_sha256"])
        with Image.open(io.BytesIO(base64.b64decode(result["png_base64"]))) as preview:
            self.assertEqual(preview.size, (256, 256))
        with rasterio.MemoryFile(exported) as memory_file:
            with memory_file.open() as dataset:
                self.assertEqual(dataset.count, 3)
                self.assertEqual(dataset.descriptions, ("Red", "Green", "Blue"))
                self.assertEqual((dataset.width, dataset.height), (256, 256))
                self.assertIsNotNone(dataset.crs)
        self.assertTrue(model.status()["loaded"])

    def test_invalid_upload_is_a_clear_validation_error(self):
        upload = upload_file("invalid.tif", b"not a tiff")
        with self.assertRaises(HTTPException) as caught:
            asyncio.run(validate(upload, stretch="input"))
        self.assertEqual(caught.exception.status_code, 422)
        self.assertIn("GeoTIFF", caught.exception.detail)

    def test_unsupported_upload_suffix_is_rejected(self):
        upload = upload_file("notes.txt", b"hello")
        with self.assertRaises(HTTPException) as caught:
            asyncio.run(validate(upload, stretch="input"))
        self.assertEqual(caught.exception.status_code, 415)


if __name__ == "__main__":
    unittest.main()
