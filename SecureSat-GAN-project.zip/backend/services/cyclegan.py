"""Cached cloudy-to-clear inference for a trained CycleGAN checkpoint."""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
CHECKPOINT = ROOT / "models" / "cyclegan_v2_best.pth"
sys.path.insert(0, str(ROOT / "src"))
from gan_models import CycleGenerator  # noqa: E402

_generator = None
_device = None
_lock = threading.Lock()


def status() -> dict:
    compatible = False
    if CHECKPOINT.is_file():
        try:
            metadata = torch.load(CHECKPOINT, map_location="cpu", weights_only=True)
            compatible = metadata.get("architecture_version") == 2
        except Exception:
            compatible = False
    return {"checkpoint": CHECKPOINT.name, "available": compatible,
            "message": None if compatible else "Retrain CycleGAN with the updated resize-convolution architecture.",
            "device": _device or ("cuda" if torch.cuda.is_available() else "cpu")}


def predict(rgb: np.ndarray) -> tuple[np.ndarray, float]:
    global _generator, _device
    if not CHECKPOINT.is_file():
        raise FileNotFoundError("CycleGAN checkpoint is missing. Train CycleGAN first; then this image action will be available.")
    if rgb.shape != (3, 256, 256) or not np.isfinite(rgb).all():
        raise ValueError("CycleGAN expects a finite 3 × 256 × 256 RGB image.")
    tensor = torch.from_numpy(rgb * 2.0 - 1.0).float().unsqueeze(0)
    with _lock:
        if _generator is None:
            _device = "cuda" if torch.cuda.is_available() else "cpu"
            state = torch.load(CHECKPOINT, map_location=_device, weights_only=True)
            if state.get("architecture_version") != 2:
                raise RuntimeError("The saved CycleGAN uses the older checkerboard-prone architecture. Retrain it with src/train_cyclegan.py before inference.")
            candidate = CycleGenerator(base_channels=int(state["base_channels"]),
                                       residual_blocks=int(state["residual_blocks"])).to(_device)
            candidate.load_state_dict(state["G_AB"], strict=True)
            candidate.eval()
            _generator = candidate
        started = time.perf_counter()
        with torch.inference_mode():
            output = ((_generator(tensor.to(_device)).squeeze(0).float().cpu().numpy() + 1.0) / 2.0).clip(0, 1)
        elapsed = time.perf_counter() - started
    return output, elapsed
