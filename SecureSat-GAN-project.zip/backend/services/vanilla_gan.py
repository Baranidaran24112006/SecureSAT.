"""Sampling service for the trained unconditional Vanilla GAN."""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
CHECKPOINT = ROOT / "models" / "vanilla_gan_v2.pth"
sys.path.insert(0, str(ROOT / "src"))
from gan_models import VanillaGenerator  # noqa: E402

_generator = None
_latent_dim = None
_device = None
_lock = threading.Lock()


def status() -> dict:
    compatible = False
    if CHECKPOINT.is_file():
        try:
            metadata = torch.load(CHECKPOINT, map_location="cpu", weights_only=True)
            compatible = metadata.get("architecture_version") == 2
        except Exception:
            compatible = False
    return {"checkpoint": CHECKPOINT.name, "available": compatible,
            "message": None if compatible else "Train the updated Vanilla GAN to replace the older artifact-prone checkpoint.",
            "device": _device or ("cuda" if torch.cuda.is_available() else "cpu")}


def generate(count: int = 4) -> tuple[np.ndarray, float]:
    global _generator, _latent_dim, _device
    if not CHECKPOINT.is_file():
        raise FileNotFoundError("Vanilla GAN checkpoint is missing. Train it with src/train_vanilla_gan.py first.")
    if count < 1 or count > 16:
        raise ValueError("Generate between 1 and 16 images at a time.")
    with _lock:
        if _generator is None:
            _device = "cuda" if torch.cuda.is_available() else "cpu"
            state = torch.load(CHECKPOINT, map_location=_device, weights_only=True)
            if state.get("architecture_version") != 2:
                raise RuntimeError("The saved Vanilla GAN uses the older checkerboard-prone architecture. Retrain it with src/train_vanilla_gan.py before sampling.")
            _latent_dim = int(state["latent_dim"])
            candidate = VanillaGenerator(_latent_dim, int(state["base_channels"])).to(_device)
            candidate.load_state_dict(state["generator"], strict=True)
            candidate.eval()
            _generator = candidate
        started = time.perf_counter()
        with torch.inference_mode():
            noise = torch.randn(count, _latent_dim, device=_device)
            images = ((_generator(noise).float().cpu().numpy() + 1.0) / 2.0).clip(0, 1)
        elapsed = time.perf_counter() - started
    return images, elapsed
