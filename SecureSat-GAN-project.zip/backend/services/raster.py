"""Raster validation, model preprocessing and scientifically explicit display/export."""
from __future__ import annotations

import base64
import hashlib
import io
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
MAX_BYTES = 64 * 1024 * 1024
EXPECTED_SIZE = 256


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_raster(data: bytes) -> tuple[np.ndarray, dict, np.ndarray]:
    if not data:
        raise ValueError("The uploaded file is empty.")
    if len(data) > MAX_BYTES:
        raise ValueError("File exceeds the 64 MiB upload limit.")
    try:
        with rasterio.MemoryFile(data) as mem:
            with mem.open() as ds:
                if ds.count < 4:
                    raise ValueError(f"Expected at least 4 bands for Sentinel-style RGB; found {ds.count}.")
                if (ds.height, ds.width) != (EXPECTED_SIZE, EXPECTED_SIZE):
                    raise ValueError(f"Expected a 256 × 256 raster; found {ds.width} × {ds.height}.")
                masked = ds.read([4, 3, 2], masked=True)
                profile = ds.profile.copy()
    except ValueError:
        raise
    except rasterio.errors.RasterioError as exc:
        raise ValueError("The file is not a readable GeoTIFF raster.") from exc
    raw = np.asarray(masked.filled(0), dtype=np.float32)
    invalid = np.ma.getmaskarray(masked).any(axis=0) | ~np.isfinite(raw).all(axis=0)
    if not np.isfinite(raw).all():
        raise ValueError("Selected RGB bands contain NaN or infinite values.")
    # Exact training preprocessing; display stretching never touches this tensor.
    reflectance = np.clip(raw / np.float32(10000.0), 0.0, 1.0)
    return reflectance, profile, invalid


def to_display(rgb_chw: np.ndarray, method: str = "shared", reference: np.ndarray | None = None) -> tuple[np.ndarray, str]:
    """Render RGB [0,1] CHW. Input mode shares per-band reference limits across images."""
    arr = np.asarray(rgb_chw, dtype=np.float32)
    if arr.ndim != 3 or arr.shape[0] != 3:
        raise ValueError("Display input must have three RGB channels in CHW order.")
    if not np.isfinite(arr).all():
        raise ValueError("Display input contains non-finite values.")
    rgb = np.moveaxis(np.clip(arr, 0.0, 1.0), 0, -1)
    label = "Shared reflectance stretch (0–1)"
    if method == "input":
        ref = arr if reference is None else np.asarray(reference, dtype=np.float32)
        if ref.ndim != 3 or ref.shape[0] != 3 or not np.isfinite(ref).all():
            raise ValueError("Input-referenced stretch needs a finite three-band RGB reference.")
        for channel in range(3):
            lo, hi = np.percentile(ref[channel], [2, 98])
            if hi > lo:
                rgb[..., channel] = np.clip((rgb[..., channel] - lo) / (hi - lo), 0.0, 1.0)
        if reference is not None and reference.shape[1] == arr.shape[1] * 3:
            label = "Joint input/output/reference per-band 2–98 stretch (shared)"
        elif reference is not None and reference.shape != arr.shape:
            label = "Joint input/output per-band 2–98 stretch (shared)"
        else:
            label = "Input-referenced per-band 2–98 stretch (shared)"
    elif method == "percentile":
        lo, hi = np.percentile(rgb, [2, 98])
        if np.isfinite(lo) and np.isfinite(hi) and hi > lo:
            rgb = np.clip((rgb - lo) / (hi - lo), 0.0, 1.0)
        label = "Independent per-image 2–98 percentile stretch"
    elif method != "shared":
        raise ValueError("Stretch must be 'shared' or 'percentile'.")
    return np.rint(rgb * 255.0).astype(np.uint8), label


def png_data_url(rgb_chw: np.ndarray, method: str = "shared", reference: np.ndarray | None = None) -> tuple[str, str]:
    image, label = to_display(rgb_chw, method, reference)
    output = io.BytesIO()
    Image.fromarray(image, mode="RGB").save(output, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(output.getvalue()).decode("ascii"), label


def export_geotiff(prediction: np.ndarray, source_profile: dict) -> bytes:
    if prediction.shape != (3, EXPECTED_SIZE, EXPECTED_SIZE) or not np.isfinite(prediction).all():
        raise ValueError("Prediction is invalid; expected finite 3 × 256 × 256 RGB output.")
    pixels = np.rint(np.clip(prediction, 0, 1) * 10000).astype(np.uint16)
    profile = {key: source_profile[key] for key in ("driver", "height", "width", "transform", "crs", "tiled") if key in source_profile}
    profile.update(driver="GTiff", count=3, dtype="uint16", compress="deflate", photometric="RGB")
    profile.pop("tiled", None) if profile.get("tiled") is False else None
    output = io.BytesIO()
    with rasterio.MemoryFile() as mem:
        with mem.open(**profile) as dst:
            dst.write(pixels)
            for index, name in enumerate(("Red", "Green", "Blue"), start=1):
                dst.set_band_description(index, name)
        output.write(mem.read())
    return output.getvalue()
