"""Cached inference for the paired cloudy-to-clear conditional GAN."""
from __future__ import annotations

import hashlib
import sys
import time
from pathlib import Path
import threading

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
CHECKPOINT = ROOT / "models" / "generator_gan_best.pth"
sys.path.insert(0, str(ROOT / "src"))
from generator import UNetGenerator  # noqa: E402

_generator = None
_device = None
_lock = threading.Lock()


def status() -> dict:
    digest = hashlib.sha256(CHECKPOINT.read_bytes()).hexdigest() if CHECKPOINT.is_file() else None
    return {"checkpoint": CHECKPOINT.name, "available": CHECKPOINT.is_file(), "sha256": digest,
            "device": _device or ("cuda" if torch.cuda.is_available() else "cpu")}


def predict(rgb: np.ndarray) -> tuple[np.ndarray, float]:
    global _generator, _device
    if not CHECKPOINT.is_file():
        raise RuntimeError("Conditional GAN checkpoint is missing; train the model first.")
    if rgb.shape != (3, 256, 256) or not np.isfinite(rgb).all():
        raise ValueError("Conditional GAN expects a finite 3 × 256 × 256 RGB image.")
    # Match src/predict_conditional_gan.py training preprocessing (8-bit RGB).
    quantized = (rgb * 255.0).astype(np.uint8).astype(np.float32) / 255.0
    tensor = torch.from_numpy(quantized * 2.0 - 1.0).float().unsqueeze(0)
    with _lock:
        if _generator is None:
            _device = "cuda" if torch.cuda.is_available() else "cpu"
            candidate = UNetGenerator(features=16).to(_device)
            candidate.load_state_dict(torch.load(CHECKPOINT, map_location=_device, weights_only=True), strict=True)
            candidate.eval()
            _generator = candidate
        started = time.perf_counter()
        with torch.inference_mode():
            output = ((_generator(tensor.to(_device)).squeeze(0).float().cpu().numpy() + 1.0) / 2.0).clip(0, 1)
        elapsed = time.perf_counter() - started
    return output, elapsed
