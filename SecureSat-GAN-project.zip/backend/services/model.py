"""Single cached instance of the project's trained reflectance U-Net."""
from __future__ import annotations

import hashlib
import sys
import threading
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
CHECKPOINT = ROOT / "models" / "generator_reflectance_best.pth"
sys.path.insert(0, str(ROOT / "src"))
from generator import UNetGenerator  # noqa: E402

_model = None
_device = None
_lock = threading.Lock()


def status() -> dict:
    return {"checkpoint": CHECKPOINT.name, "checkpoint_available": CHECKPOINT.is_file(),
            "loaded": _model is not None, "device": _device or ("cuda" if torch.cuda.is_available() else "cpu"),
            "sha256": _hash_checkpoint() if CHECKPOINT.is_file() else None}


def _hash_checkpoint() -> str:
    digest = hashlib.sha256()
    with CHECKPOINT.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def predict(tensor: torch.Tensor) -> tuple[np.ndarray, float]:
    global _model, _device
    if not CHECKPOINT.is_file():
        raise RuntimeError("The configured restoration checkpoint is unavailable.")
    if tensor.shape != (3, 256, 256) or not torch.isfinite(tensor).all():
        raise ValueError("Model input must be a finite 3 × 256 × 256 tensor.")
    with _lock:
        if _model is None:
            _device = "cuda" if torch.cuda.is_available() else "cpu"
            candidate = UNetGenerator(features=16).to(torch.device(_device))
            state = torch.load(CHECKPOINT, map_location=_device, weights_only=True)
            candidate.load_state_dict(state, strict=True)
            candidate.eval()
            _model = candidate
        started = __import__("time").perf_counter()
        with torch.inference_mode():
            result = _model(tensor.unsqueeze(0).to(_device)).squeeze(0).float().cpu()
        duration = __import__("time").perf_counter() - started
    if tuple(result.shape) != (3, 256, 256) or not torch.isfinite(result).all():
        raise RuntimeError("The checkpoint returned an invalid or non-finite prediction.")
    if float(result.min()) < -1.001 or float(result.max()) > 1.001:
        raise RuntimeError("The checkpoint output is outside the expected tanh range.")
    return ((result.clamp(-1, 1).numpy() + 1.0) / 2.0), duration
