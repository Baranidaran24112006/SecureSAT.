"""SecureSat-GAN local inference API."""
