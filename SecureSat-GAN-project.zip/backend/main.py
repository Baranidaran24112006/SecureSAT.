"""FastAPI application for local SecureSat-GAN processing."""
from __future__ import annotations

import base64
from pathlib import Path
from threading import BoundedSemaphore
from typing import Annotated

import numpy as np
import rasterio
import torch
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles

from backend.services import model
from backend.services import conditional_gan
from backend.services import attention_gan
from backend.services.raster import MAX_BYTES, ROOT, export_geotiff, png_data_url, read_raster, sha256

app = FastAPI(title="SecureSat-GAN Local API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["GET", "POST"], allow_headers=["Content-Type"])
_inference_slot = BoundedSemaphore(1)
SAMPLES = ROOT / "data" / "raw" / "cloudy"
CLEAR = ROOT / "data" / "raw" / "clear"


class IntegrityRequest(BaseModel):
    sha256: str
    expected_sha256: str | None = None


async def upload_bytes(file: UploadFile) -> bytes:
    if Path(file.filename or "").suffix.lower() not in {".tif", ".tiff"}:
        await file.close()
        raise HTTPException(415, "Upload a .tif or .tiff GeoTIFF file.")
    data = await file.read(MAX_BYTES + 1)
    await file.close()
    if len(data) > MAX_BYTES:
        await file.close()
        raise HTTPException(413, "File exceeds the 64 MiB upload limit.")
    return data


def selected_sample(name: str) -> Path:
    # Resolve only names from the explicit local sample directory; no caller path is opened.
    if Path(name).name != name or Path(name).suffix.lower() not in {".tif", ".tiff"}:
        raise HTTPException(400, "Choose a listed sample GeoTIFF.")
    path = SAMPLES / name
    if not path.is_file():
        raise HTTPException(404, "The selected sample is no longer available.")
    return path


@app.get("/api/health")
def health():
    return {"status": "ok", "device": "cuda" if torch.cuda.is_available() else "cpu"}


@app.get("/api/model")
def model_status():
    return model.status()


@app.get("/api/gan/status")
def gan_status():
    return {"pix2pix": conditional_gan.status(), "attention": attention_gan.status()}


@app.get("/api/samples")
def samples():
    entries = []
    if SAMPLES.is_dir():
        for path in sorted([*SAMPLES.glob("*.tif"), *SAMPLES.glob("*.tiff")]):
            entries.append({"name": path.name, "has_reference": (CLEAR / path.name).is_file()})
    return {"samples": entries}


@app.get("/api/samples/{name}/preview")
def sample_preview(name: str, stretch: str = "input"):
    path = selected_sample(name)
    data = path.read_bytes()
    try:
        rgb, profile, invalid = read_raster(data)
        preview, stretch_label = png_data_url(rgb, stretch)
    except (ValueError, rasterio.errors.RasterioError) as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"name": path.name, "width": profile["width"], "height": profile["height"],
            "bands": profile["count"], "crs": str(profile.get("crs") or "Not defined"),
            "invalid_pixels": int(invalid.sum()), "preview": preview, "stretch": stretch_label,
            "sha256": sha256(data)}


async def payload(file: UploadFile | None, sample: str | None) -> tuple[bytes, str, bool]:
    if (file is None) == (sample is None):
        raise HTTPException(400, "Provide exactly one uploaded file or listed sample name.")
    if file is not None:
        return await upload_bytes(file), Path(file.filename or "upload.tif").name, False
    path = selected_sample(sample or "")
    data = path.read_bytes()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "Selected sample exceeds the 64 MiB processing limit.")
    return data, path.name, True


@app.post("/api/validate")
async def validate(file: Annotated[UploadFile, File()], stretch: str = "input"):
    data = await upload_bytes(file)
    try:
        rgb, profile, invalid = read_raster(data)
        preview, stretch_label = png_data_url(rgb, stretch)
    except (ValueError, rasterio.errors.RasterioError) as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"name": Path(file.filename or "upload.tif").name, "width": profile["width"], "height": profile["height"],
            "bands": profile["count"], "crs": str(profile.get("crs") or "Not defined"),
            "invalid_pixels": int(invalid.sum()), "preview": preview, "stretch": stretch_label,
            "sha256": sha256(data)}


@app.post("/api/restore")
async def restore(file: Annotated[UploadFile | None, File()] = None,
                  sample: Annotated[str | None, Form()] = None,
                  stretch: Annotated[str, Form()] = "input"):
    data, name, is_sample = await payload(file, sample)
    try:
        rgb, profile, invalid = read_raster(data)
        if invalid.any():
            raise ValueError(f"Raster contains {int(invalid.sum())} masked/no-data RGB pixels; this model requires complete 256 × 256 RGB coverage.")
        if not _inference_slot.acquire(blocking=False):
            raise HTTPException(429, "A restoration is already running. Try again shortly.")
        try:
            tensor = torch.from_numpy(rgb * 2.0 - 1.0).float()
            restored, elapsed = model.predict(tensor)
        finally:
            _inference_slot.release()
        reference_metrics = None
        reference_preview = None
        clear_rgb = None
        if is_sample and (CLEAR / name).is_file():
            clear_bytes = (CLEAR / name).read_bytes()
            candidate, _, clear_invalid = read_raster(clear_bytes)
            if not clear_invalid.any():
                clear_rgb = candidate
        display_arrays = [rgb, restored, *([clear_rgb] if clear_rgb is not None else [])]
        display_reference = np.concatenate(display_arrays, axis=1) if stretch == "input" else None
        input_png, stretch_label = png_data_url(rgb, stretch, reference=display_reference)
        output_png, _ = png_data_url(restored, stretch, reference=display_reference)
        tiff = export_geotiff(restored, profile)
        if clear_rgb is not None:
            reference_preview, _ = png_data_url(clear_rgb, stretch, reference=display_reference)
            error = restored.astype(np.float64) - clear_rgb.astype(np.float64)
            mae = float(np.abs(error).mean())
            mse = float(np.square(error).mean())
            reference_metrics = {"mae": mae, "psnr_db": None if mse == 0 else float(10 * np.log10(1.0 / mse)),
                                 "range": "reflectance [0,1]", "reference": name}
        return {"name": name, "input_preview": input_png, "restored_preview": output_png,
                "reference_preview": reference_preview, "stretch": stretch_label, "elapsed_seconds": elapsed,
                "model": model.status(), "input_sha256": sha256(data), "output_sha256": sha256(tiff),
                "geotiff_base64": base64.b64encode(tiff).decode("ascii"),
                "png_base64": output_png.split(",", 1)[1], "reference_metrics": reference_metrics}
    except HTTPException:
        raise
    except (ValueError, rasterio.errors.RasterioError) as exc:
        raise HTTPException(422, str(exc)) from exc
    except Exception as exc:
        # Keep traces and host paths in server logs only.
        import logging
        logging.getLogger("securesat").exception("Restore failed")
        raise HTTPException(503, "Restoration could not be completed. Check model availability and server logs.") from exc


@app.post("/api/gan/conditional")
async def run_conditional_gan(file: Annotated[UploadFile | None, File()] = None,
                             sample: Annotated[str | None, Form()] = None,
                             stretch: Annotated[str, Form()] = "input"):
    """Run the trained paired cGAN on an uploaded or listed 256px satellite TIFF."""
    data, name, _ = await payload(file, sample)
    try:
        rgb, profile, invalid = read_raster(data)
        if invalid.any():
            raise ValueError(f"Raster contains {int(invalid.sum())} masked/no-data RGB pixels; the model requires complete RGB coverage.")
        if not _inference_slot.acquire(blocking=False):
            raise HTTPException(429, "Another image model is running. Try again shortly.")
        try:
            prediction, elapsed = conditional_gan.predict(rgb)
        finally:
            _inference_slot.release()
        joint = np.concatenate((rgb, prediction), axis=1)
        input_png, label = png_data_url(rgb, stretch, reference=joint if stretch == "input" else None)
        output_png, _ = png_data_url(prediction, stretch, reference=joint if stretch == "input" else None)
        tiff = export_geotiff(prediction, profile)
        return {"name": name, "input_preview": input_png, "output_preview": output_png,
                "stretch": label, "elapsed_seconds": elapsed,
                "checkpoint": conditional_gan.status(), "input_sha256": sha256(data),
                "output_sha256": sha256(tiff), "geotiff_base64": base64.b64encode(tiff).decode("ascii")}
    except HTTPException:
        raise
    except (ValueError, rasterio.errors.RasterioError) as exc:
        raise HTTPException(422, str(exc)) from exc
    except Exception as exc:
        import logging
        logging.getLogger("securesat").exception("Conditional GAN inference failed")
        raise HTTPException(503, "Conditional GAN could not run. Check that its checkpoint is available.") from exc


@app.post("/api/gan/attention")
async def run_attention_gan(file: Annotated[UploadFile | None, File()] = None,
                            sample: Annotated[str | None, Form()] = None,
                            stretch: Annotated[str, Form()] = "input"):
    """Run the paired attention cGAN on an uploaded or listed satellite TIFF."""
    data, name, _ = await payload(file, sample)
    try:
        rgb, profile, invalid = read_raster(data)
        if invalid.any():
            raise ValueError(f"Raster contains {int(invalid.sum())} masked/no-data RGB pixels; the model requires complete RGB coverage.")
        if not _inference_slot.acquire(blocking=False):
            raise HTTPException(429, "Another image model is running. Try again shortly.")
        try:
            prediction, elapsed = attention_gan.predict(rgb)
        finally:
            _inference_slot.release()
        joint = np.concatenate((rgb, prediction), axis=1)
        input_png, label = png_data_url(rgb, stretch, reference=joint if stretch == "input" else None)
        output_png, _ = png_data_url(prediction, stretch, reference=joint if stretch == "input" else None)
        tiff = export_geotiff(prediction, profile)
        return {"name": name, "input_preview": input_png, "output_preview": output_png,
                "stretch": label, "elapsed_seconds": elapsed, "checkpoint": attention_gan.status(),
                "input_sha256": sha256(data), "output_sha256": sha256(tiff),
                "geotiff_base64": base64.b64encode(tiff).decode("ascii")}
    except HTTPException:
        raise
    except FileNotFoundError as exc:
        raise HTTPException(409, str(exc)) from exc
    except (ValueError, rasterio.errors.RasterioError) as exc:
        raise HTTPException(422, str(exc)) from exc
    except Exception as exc:
        import logging
        logging.getLogger("securesat").exception("Attention cGAN inference failed")
        raise HTTPException(503, "Attention cGAN could not run. Check its checkpoint and image.") from exc


@app.post("/api/integrity/verify")
def verify_integrity(request: IntegrityRequest):
    given = request.sha256.lower()
    if len(given) != 64 or any(ch not in "0123456789abcdef" for ch in given):
        raise HTTPException(422, "SHA-256 must contain exactly 64 hexadecimal characters.")
    expected = request.expected_sha256.lower() if request.expected_sha256 else None
    if expected and (len(expected) != 64 or any(ch not in "0123456789abcdef" for ch in expected)):
        raise HTTPException(422, "Expected SHA-256 must contain exactly 64 hexadecimal characters.")
    return {"sha256": given, "matches_expected": (given == expected) if expected else None,
            "meaning": "A matching hash verifies byte equality against the supplied checksum; it does not establish authenticity."}


# Serve the checked-in/local production build from the same process so the app
# can run without a separate JavaScript dev server. API routes above take priority.
WEB_DIST = ROOT / "frontend" / "dist"
if WEB_DIST.is_dir():
    app.mount("/", StaticFiles(directory=WEB_DIST, html=True), name="web-client")
