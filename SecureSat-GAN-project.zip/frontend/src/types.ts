export type Sample = { name: string; has_reference: boolean };
export type ModelStatus = { checkpoint: string; checkpoint_available: boolean; loaded: boolean; device: string; sha256: string | null };
export type Validation = { name: string; width: number; height: number; bands: number; crs: string; invalid_pixels: number; preview: string; stretch: string; sha256: string };
export type Metrics = { mae: number; psnr_db: number | null; range: string; reference: string } | null;
export type Restoration = { name: string; input_preview: string; restored_preview: string; reference_preview: string | null; stretch: string; elapsed_seconds: number; model: ModelStatus; input_sha256: string; output_sha256: string; geotiff_base64: string; png_base64: string; reference_metrics: Metrics };
export type GanResult = { name: string; input_preview: string; output_preview: string; stretch: string; elapsed_seconds: number; checkpoint: { checkpoint: string; available: boolean; sha256: string | null; device: string }; input_sha256: string; output_sha256: string; geotiff_base64: string };
export type GanModelState = { checkpoint: string; available: boolean; device: string };
export type GanStatuses = { pix2pix: GanModelState; attention: GanModelState };
