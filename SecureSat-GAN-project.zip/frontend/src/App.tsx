import { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowDownToLine, Check, ChevronDown, CircleHelp, Cloud, Cpu, FileCheck2, Fingerprint, Focus, Gauge, ImagePlus, Layers3, LockKeyhole, Network, ScanLine, ShieldCheck, Upload, X } from 'lucide-react';
import { api } from './api';
import './gan.css';
import type { GanResult, GanStatuses, ModelStatus, Restoration, Sample, Validation } from './types';

type Page = 'workspace' | 'integrity' | 'about' | 'gan';
function App() {
  const [page, setPage] = useState<Page>('workspace');
  const [healthy, setHealthy] = useState<boolean | null>(null);
  const [device, setDevice] = useState('—');
  const [model, setModel] = useState<ModelStatus | null>(null);
  const [samples, setSamples] = useState<Sample[]>([]);
  const [sample, setSample] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [validation, setValidation] = useState<Validation | null>(null);
  const [result, setResult] = useState<Restoration | null>(null);
  const [ganResult, setGanResult] = useState<GanResult | null>(null);
  const [ganMode, setGanMode] = useState<'pix2pix' | 'attention'>('pix2pix');
  const [ganStatuses, setGanStatuses] = useState<GanStatuses | null>(null);
  const [stretch, setStretch] = useState('input');
  const [busy, setBusy] = useState<'validate' | 'restore' | null>(null);
  const [ganBusy, setGanBusy] = useState(false);
  const [error, setError] = useState('');
  const [split, setSplit] = useState(50);
  const [mode, setMode] = useState<'slider' | 'side' | 'reference'>('slider');
  const [zoom, setZoom] = useState(100);
  const [expected, setExpected] = useState('');
  const [digest, setDigest] = useState('');
  const [verifyText, setVerifyText] = useState('');
  const [verifyMatch, setVerifyMatch] = useState<boolean | null>(null);
  useEffect(() => {
    void api.health().then((h) => { setHealthy(h.status === 'ok'); setDevice(h.device.toUpperCase()); }).catch(() => setHealthy(false));
    void api.model().then(setModel).catch(() => setModel(null));
    void api.ganStatus().then(setGanStatuses).catch(() => setGanStatuses(null));
    void api.samples().then((v) => { setSamples(v.samples); if (v.samples[0]) void chooseSample(v.samples[0].name); }).catch(() => setSamples([]));
  }, []);

  const selectedSample = useMemo(() => samples.find((item) => item.name === sample), [samples, sample]);
  function clearResult() { setResult(null); setGanResult(null); setValidation(null); setError(''); }
  async function chooseFile(next: File | null) {
    clearResult(); setFile(next);
    if (!next) return;
    setSample(''); setBusy('validate');
    try { setValidation(await api.validate(next, stretch)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Image validation failed.'); }
    finally { setBusy(null); }
  }
  async function chooseSample(name: string) {
    setFile(null); setResult(null); setGanResult(null); setValidation(null); setError(''); setSample(name);
    if (!name) return;
    setBusy('validate');
    try { setValidation(await api.samplePreview(name, stretch)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Sample preview failed.'); }
    finally { setBusy(null); }
  }
  async function runRestore() {
    if (!file && !sample) { setError('Choose a listed sample or upload a GeoTIFF first.'); return; }
    setError(''); setBusy('restore'); setResult(null);
    try { setResult(await api.restore(file, file ? null : sample, stretch)); setSplit(50); setMode('slider'); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Restoration failed.'); }
    finally { setBusy(null); }
  }
  async function runSelectedGan() {
    setError(''); setGanBusy(true); setGanResult(null);
    try {
      if (!file && !sample) throw new Error('Choose an image in Restoration first, or upload a GeoTIFF there.');
      const input = [file, file ? null : sample, stretch] as const;
      setGanResult(ganMode === 'pix2pix' ? await api.conditionalGan(...input) : await api.attentionGan(...input));
    } catch (cause) { setError(cause instanceof Error ? cause.message : `${ganMode} GAN could not generate an image.`); }
    finally { setGanBusy(false); }
  }
  async function chooseStretch(next: string) {
    setStretch(next);
    if (result) return;
    setError('');
    try {
      if (file) setValidation(await api.validate(file, next));
      else if (sample) setValidation(await api.samplePreview(sample, next));
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not render this display stretch.'); }
  }
  function download(data: string, name: string, mime: string) {
    const binary = atob(data); const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
    const link = document.createElement('a'); link.href = url; link.download = name; link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function verify(hash: string) {
    if (!/^[a-f\d]{64}$/i.test(hash)) { setVerifyText('Enter a valid 64-character SHA-256 checksum.'); setVerifyMatch(null); return; }
    try { const answer = await api.verify(hash, expected.trim() || undefined); setVerifyText(answer.meaning); setVerifyMatch(answer.matches_expected); }
    catch (cause) { setVerifyText(cause instanceof Error ? cause.message : 'Verification failed.'); setVerifyMatch(null); }
  }

  const translationResult = ganResult;
  const activeGanStatus = ganStatuses?.[ganMode];

  return <div className="shell">
    <aside className="rail">
      <div className="brand"><div className="brand-mark"><ScanLine size={19}/></div><span>SECURE<span className="brand-light">SAT</span><small>EARTH OBSERVATION</small></span></div>
      <div className="rail-label">WORKSPACE</div>
      <nav aria-label="Main navigation">
        <button className={page === 'workspace' ? 'nav active' : 'nav'} onClick={() => setPage('workspace')}><Layers3 size={17}/> Restoration</button>
        <button className={page === 'gan' ? 'nav active' : 'nav'} onClick={() => setPage('gan')}><Network size={17}/> GAN concepts</button>
        <button className={page === 'integrity' ? 'nav active' : 'nav'} onClick={() => setPage('integrity')}><Fingerprint size={17}/> Integrity</button>
        <button className={page === 'about' ? 'nav active' : 'nav'} onClick={() => setPage('about')}><CircleHelp size={17}/> Project notes</button>
      </nav>
      <div className="rail-bottom"><div className="local-mark"><LockKeyhole size={14}/> LOCAL PROCESSING</div><p>Images stay on this machine. No external imagery service is used.</p><div className="build">SECURESAT-GAN <span>·</span> 1.0</div></div>
    </aside>

    <main className="main">
      <header className="topbar"><div className="crumb">MISSION WORKSPACE <span>/</span> {page === 'workspace' ? 'RESTORATION' : page === 'integrity' ? 'INTEGRITY' : page === 'gan' ? 'GAN CONCEPTS' : 'PROJECT NOTES'}</div>
        <div className="top-state"><span className={`status-dot ${healthy ? 'good' : healthy === false ? 'bad' : ''}`}/>{healthy === null ? 'CONNECTING' : healthy ? 'LOCAL API ONLINE' : 'API OFFLINE'}<i/></div>
      </header>

      {page === 'workspace' && <>
        <section className="intro"><div><div className="eyebrow"><Activity size={13}/> EARTH OBSERVATION / IMAGE SCIENCE</div><h1>Restoration workspace</h1><p>Inspect an input scene, run the trained RGB model, and compare the returned image products.</p></div><div className="intro-meta"><span>INFERENCE DEVICE</span><strong><Cpu size={15}/> {device}</strong></div></section>

        <section className="work-grid">
          <div className="control-column">
            <section className="panel source-panel"><div className="panel-head"><span className="step">01</span><div><h2>Source imagery</h2><p>256 × 256 GeoTIFF · at least 4 bands</p></div><ImagePlus size={17} className="quiet-icon"/></div>
              <label className="field-label" htmlFor="sample">LOCAL SAMPLE <span>· {samples.length} AVAILABLE</span></label>
              <div className="select-wrap"><select id="sample" value={file ? '' : sample} onChange={(event) => void chooseSample(event.target.value)}><option value="">Select a sample scene</option>{samples.map((item) => <option key={item.name} value={item.name}>{item.name}{item.has_reference ? ' · paired reference' : ''}</option>)}</select><ChevronDown size={15}/></div>
              <div className="or-line"><span>OR</span></div>
              <label className="upload-box"><Upload size={17}/><strong>{file ? file.name : 'Upload a GeoTIFF'}</strong><small>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MiB` : 'TIF or TIFF · up to 64 MiB'}</small><input type="file" accept=".tif,.tiff,image/tiff" onChange={(event) => void chooseFile(event.target.files?.[0] ?? null)}/></label>
              {(validation || (selectedSample && !file)) && <div className="validation-note"><Check size={14}/><span>{validation ? `${validation.width} × ${validation.height} · ${validation.bands} bands · ${validation.crs}` : `Selected ${selectedSample?.name}`}</span></div>}
              <label className="field-label stretch-label" htmlFor="stretch">{result ? 'STRETCH FOR NEXT RUN' : 'DISPLAY STRETCH'}</label><div className="select-wrap"><select id="stretch" value={stretch} onChange={(event) => void chooseStretch(event.target.value)}><option value="input">Input-referenced RGB · shared</option><option value="shared">Reflectance · 0–1</option><option value="percentile">Independent 2–98 percentile</option></select><ChevronDown size={15}/></div>
              <p className="hint">The stretch affects preview appearance only. Model input always uses training reflectance scaling.</p>
              <button className="run-button" onClick={() => void runRestore()} disabled={busy !== null || (!file && !sample) || healthy === false}><Cloud size={16}/>{busy === 'restore' ? 'Running model…' : 'Run restoration'}<span>↗</span></button>
              {busy === 'validate' && <div className="busy-line"><span className="spinner"/>Validating raster metadata and RGB bands…</div>}
              {error && <div className="error-box" role="alert"><X size={15}/>{error}</div>}
            </section>
            <section className="panel model-panel"><div className="panel-head compact"><span className="model-orb"><Activity size={16}/></span><div><h2>Model status</h2><p>{model?.checkpoint ?? 'Checking checkpoint'}</p></div><span className={`pill ${model?.checkpoint_available ? 'pill-good' : 'pill-bad'}`}>{model?.checkpoint_available ? 'AVAILABLE' : model ? 'MISSING' : 'CHECKING'}</span></div>
              <div className="model-details"><div><span>ARCHITECTURE</span><b>U-Net · RGB / 3 band</b></div><div><span>COMPUTE</span><b>{model?.device.toUpperCase() ?? device}</b></div>{model?.sha256 && <div className="hash-line"><span>CHECKPOINT SHA-256</span><code>{model.sha256.slice(0, 20)}…</code></div>}</div>
            </section>
          </div>

          <section className="panel viewer-panel"><div className="viewer-header"><div><div className="section-kicker">02 / VISUAL INSPECTION</div><h2>{result ? result.name : 'Image comparison'}</h2></div>{result && <div className="view-tools"><button className={mode === 'slider' ? 'tool active-tool' : 'tool'} onClick={() => setMode('slider')}>COMPARE</button><button className={mode === 'side' ? 'tool active-tool' : 'tool'} onClick={() => setMode('side')}>SIDE BY SIDE</button>{result.reference_preview && <button className={mode === 'reference' ? 'tool active-tool' : 'tool'} onClick={() => setMode('reference')}>REFERENCE</button>}</div>}</div>
            {result ? <>
              {mode === 'slider' ? <div className="compare-frame" style={{'--split': `${split}%`, '--zoom': `${zoom}%`} as React.CSSProperties}><img className="base-image" src={result.input_preview} alt="Original cloudy satellite image"/><div className="restored-clip"><img src={result.restored_preview} alt="Restored satellite image"/></div><div className="image-tag tag-left">CLOUDY INPUT</div><div className="image-tag tag-right">RESTORED</div><div className="split-line" style={{left: `${split}%`}}/><input aria-label="Before and after comparison slider" className="split-control" type="range" min="0" max="100" value={split} onChange={(event) => setSplit(Number(event.target.value))}/></div> : mode === 'side' ? <div className="side-images" style={{'--zoom': `${zoom}%`} as React.CSSProperties}><figure><img src={result.input_preview} alt="Original cloudy satellite image"/><figcaption>CLOUDY INPUT</figcaption></figure><figure><img src={result.restored_preview} alt="Restored satellite image"/><figcaption>RESTORED OUTPUT</figcaption></figure></div> : <div className="side-images reference-images" style={{'--zoom': `${zoom}%`} as React.CSSProperties}><figure><img src={result.input_preview} alt="Original cloudy satellite image"/><figcaption>CLOUDY INPUT</figcaption></figure><figure><img src={result.restored_preview} alt="Restored satellite image"/><figcaption>RESTORED OUTPUT</figcaption></figure><figure><img src={result.reference_preview ?? ''} alt="Paired clear reference satellite image"/><figcaption>CLEAR REFERENCE</figcaption></figure></div>}
              <div className="viewer-controls"><div className="zoom-control"><Focus size={15}/><span>ZOOM</span><input aria-label="Image zoom" type="range" min="75" max="200" step="5" value={zoom} onChange={(event) => setZoom(Number(event.target.value))}/><b>{zoom}%</b><button onClick={() => setZoom(100)}>RESET</button></div><span className="stretch-label-view">{result.stretch}</span></div>
              <div className="result-strip"><div><Gauge size={16}/><span>INFERENCE</span><b>{result.elapsed_seconds.toFixed(2)} s</b></div><div><Layers3 size={16}/><span>OUTPUT PRODUCT</span><b>3-band RGB GeoTIFF</b></div><div className="export-actions"><button className="download-button" onClick={() => download(atob(result.geotiff_base64), `restored_${result.name.replace(/\.(tif|tiff)$/i, '')}.tif`, 'image/tiff')}><ArrowDownToLine size={15}/> GeoTIFF</button><button className="download-button secondary-download" onClick={() => download(atob(result.png_base64), `preview_${result.name.replace(/\.(tif|tiff)$/i, '')}.png`, 'image/png')}>PNG preview</button></div></div>
              {result.reference_metrics && <div className="metrics-note"><div><span>PAIRED CLEAR REFERENCE</span><b>{result.reference_metrics.reference}</b></div><div><span>MAE · REFLECTANCE [0–1]</span><b>{result.reference_metrics.mae.toFixed(5)}</b></div><div><span>PSNR</span><b>{result.reference_metrics.psnr_db === null ? '∞ dB' : `${result.reference_metrics.psnr_db.toFixed(2)} dB`}</b></div><p>Reference metrics summarize pixel agreement and do not prove recovery of hidden ground detail.</p></div>}
              <div className="integrity-inline"><ShieldCheck size={16}/><span>INPUT SHA-256</span><code>{result.input_sha256.slice(0, 17)}…</code><span>OUTPUT</span><code>{result.output_sha256.slice(0, 17)}…</code><button onClick={() => setPage('integrity')}>VERIFY HASHES</button></div>
            </> : <div className="empty-view">{validation ? <><img className="source-preview" src={validation.preview} alt="Selected cloudy satellite source image"/><div className="preview-label">SOURCE PREVIEW · {validation.name}</div><h3>Ready for restoration</h3><p>{validation.width} × {validation.height} · {validation.bands} bands · {validation.crs}</p></> : <><div className="empty-grid"><div className="satellite-mark"><ScanLine size={28}/></div><div className="crosshair h"/><div className="crosshair v"/></div><h3>Awaiting image data</h3><p>Choose a local scene or upload a GeoTIFF to begin inspection.</p></>}<div className="empty-foot"><span><span className="mini-dot"/> PIXEL VALUES UNMODIFIED</span><span>RGB DISPLAY · {stretch === 'input' ? 'INPUT-REFERENCED' : stretch === 'shared' ? 'FIXED REFLECTANCE' : 'INDEPENDENT PERCENTILES'}</span></div></div>}
          </section>
        </section>
        <section className="bottom-note"><div><ShieldCheck size={15}/> PROCESSING STAYS LOCAL</div><p>Restored output is the model’s three-channel prediction. Missing scene detail is estimated, not verified ground truth.</p><span> <FileCheck2 size={14}/> GeoTIFF preserves CRS and transform where provided</span></section>
      </>}

      {page === 'integrity' && <section className="page-content"><div className="eyebrow"><Fingerprint size={14}/> FILE VERIFICATION</div><h1>Integrity verification</h1><p className="page-lede">Compare a file digest with a checksum you trust. Hash equality confirms matching bytes only; it does not prove a file’s origin or scientific accuracy.</p>
        <section className="panel integrity-panel"><div className="panel-head"><span className="step">SHA</span><div><h2>Verify a SHA-256 digest</h2><p>Use the current restoration file hashes or paste a digest to compare.</p></div></div>
          {result && <div className="hash-card"><div><span>RESTORATION INPUT</span><code>{result.input_sha256}</code><button onClick={() => void verify(result.input_sha256)}>CHECK</button></div><div><span>RESTORATION OUTPUT</span><code>{result.output_sha256}</code><button onClick={() => void verify(result.output_sha256)}>CHECK</button></div></div>}
          <label className="field-label" htmlFor="hash-input">SHA-256 TO VERIFY</label><input id="hash-input" className="text-input" value={digest} onChange={(event) => { setDigest(event.target.value); setVerifyText(''); setVerifyMatch(null); }} placeholder="Paste a 64-character SHA-256 digest"/>
          <label className="field-label" htmlFor="expected">OPTIONAL TRUSTED CHECKSUM</label><input id="expected" className="text-input" value={expected} onChange={(event) => setExpected(event.target.value)} placeholder="Compare against this expected digest"/>
          <button className="run-button verify-button" onClick={() => void verify(digest)}><ShieldCheck size={16}/> Verify checksum</button>
          {verifyText && <div className={`verify-result ${verifyMatch === true ? 'verify-good' : verifyMatch === false ? 'verify-bad' : ''}`}>{verifyMatch === true ? <Check size={16}/> : verifyMatch === false ? <X size={16}/> : <CircleHelp size={16}/>}<span>{verifyMatch === true ? 'Digest matches the supplied trusted checksum.' : verifyMatch === false ? 'Digest does not match the supplied trusted checksum.' : verifyText}</span></div>}
        </section><div className="honesty"><LockKeyhole size={16}/><span>Checksums detect byte changes only when compared with a trusted value. A checksum alone does not authenticate satellite data.</span></div>
      </section>}

      {page === 'about' && <section className="page-content"><div className="eyebrow"><CircleHelp size={14}/> SYSTEM NOTES</div><h1>Project notes</h1><p className="page-lede">SecureSat-GAN is a local research workflow for inspecting Sentinel-style multispectral GeoTIFFs and a trained cloud-restoration model.</p><div className="notes-grid"><section className="panel note-card"><h2>Model input</h2><p>Reads raster bands 4, 3, 2 as RGB, divides by 10,000, clips reflectance to [0,1], and maps values to [−1,1] as in the existing training loader.</p></section><section className="panel note-card"><h2>Display</h2><p>Shared stretch maps [0,1] reflectance to display values. Independent 2–98 percentile stretch can change relative brightness and color appearance. Neither changes inference input.</p></section><section className="panel note-card"><h2>Restoration limitations</h2><p>The network returns three RGB channels. Cloud-hidden content is inferred by the model; visual output is not proof of actual ground conditions. Output is not a 13-band spectral product.</p></section><section className="panel note-card"><h2>Integrity</h2><p>SHA-256 reports byte-level file identity against a known digest. It does not establish data authenticity, sensor provenance or restoration quality.</p></section></div><div className="notes-foot"><Cpu size={16}/> CPU inference supported <span>·</span> Model: {model?.checkpoint ?? 'checkpoint status unavailable'} <span>·</span> Upload limit: 64 MiB</div></section>}

      {page === 'gan' && <section className="page-content gan-page"><div className="eyebrow"><Network size={14}/> PAIRED SATELLITE RESTORATION</div><h1>Compare restoration GANs</h1><p className="page-lede">Both models use your cloudy image and aligned clear training pairs to estimate the same scene.</p>
        <div className="gan-studio panel"><div className="gan-selector" role="tablist" aria-label="Choose a paired restoration GAN">
          {([['pix2pix','Pix2Pix GAN'],['attention','Attention cGAN']] as const).map(([id,label]) => <button key={id} role="tab" aria-selected={ganMode === id} className={ganMode === id ? 'gan-select active' : 'gan-select'} onClick={() => { setGanMode(id); setGanResult(null); setError(''); }}><span>{label}</span><small>{ganStatuses?.[id]?.available ? 'READY' : ganStatuses ? 'NEEDS TRAINING' : 'CHECKING'}</small></button>)}
        </div><div className="gan-studio-head"><div><div className="section-kicker">PAIRED CLOUD-TO-CLEAR TRANSLATION</div><h2>{translationResult?.name ?? file?.name ?? sample ?? 'No source image selected'}</h2><p>{ganMode === 'pix2pix' ? 'Pix2Pix uses a U-Net generator and PatchGAN discriminator with paired reconstruction loss.' : 'Attention gates help the U-Net focus on relevant scene structures while translating aligned cloudy/clear pairs.'}</p></div><span className={`pill ${activeGanStatus?.available ? 'pill-good' : 'pill-bad'}`}>{activeGanStatus?.available ? 'CHECKPOINT READY' : 'TRAIN REQUIRED'}</span></div>
          {!translationResult ? <div className="gan-studio-preview">{validation ? <img src={validation.preview} alt="Selected satellite image for GAN translation"/> : <div><ImagePlus size={28}/><b>Choose a satellite image first</b><span>Use Restoration to select a sample or upload a GeoTIFF.</span></div>}<div className="gan-studio-label">{validation ? 'CLOUDY INPUT SCENE' : 'WAITING FOR INPUT'}</div></div> : <div className="gan-live-images"><figure><img src={translationResult.input_preview} alt="Cloudy satellite input"/><figcaption>CLOUDY INPUT</figcaption></figure><figure><img src={translationResult.output_preview} alt="GAN estimated clear image"/><figcaption>ESTIMATED CLEAR OUTPUT</figcaption></figure></div>}
          <div className="gan-live-actions"><button className="run-button" onClick={() => void runSelectedGan()} disabled={ganBusy || !activeGanStatus?.available || !file && !sample || healthy === false}><Network size={16}/>{ganBusy ? 'Generating estimate…' : `Generate with ${ganMode === 'pix2pix' ? 'Pix2Pix' : 'Attention cGAN'}`}<span>↗</span></button>{translationResult && <button className="download-button" onClick={() => download(translationResult.geotiff_base64, `${ganMode}_restored_${translationResult.name.replace(/\.(tif|tiff)$/i, '')}.tif`, 'image/tiff')}><ArrowDownToLine size={15}/> Download GeoTIFF</button>}</div>
          {ganBusy && <div className="busy-line"><span className="spinner"/>Translating the selected satellite scene…</div>}{error && page === 'gan' && <div className="error-box" role="alert"><X size={15}/>{error}</div>}{translationResult && <div className="gan-result-meta"><span>INFERENCE <b>{translationResult.elapsed_seconds.toFixed(2)} s</b></span><span>MODEL <b>{ganMode === 'pix2pix' ? 'Pix2Pix GAN' : 'Attention cGAN'} · {translationResult.checkpoint.device.toUpperCase()}</b></span><span>PRODUCT <b>3-band GeoTIFF</b></span></div>}
        </div>
        <div className="gan-grid"><section className="panel gan-card"><div className="gan-card-top"><span>01</span><b>PAIRED PIX2PIX</b></div><h2>Pix2Pix GAN</h2><p>Uses the cloudy image as input and its aligned clear image as the target. This is the project’s existing trained conditional GAN.</p><div className="gan-flow"><span>Cloudy input</span><i>→</i><span>U-Net + PatchGAN</span><i>→</i><span>Clear estimate</span></div><p className="gan-detail"><b>Training:</b> paired adversarial and L1 reconstruction losses.</p><code>.venv/bin/python src/train_conditional_gan.py</code><small>Checkpoint: models/generator_gan_best.pth</small></section>
          <section className="panel gan-card"><div className="gan-card-top"><span>02</span><b>ATTENTION PAIRED GAN</b></div><h2>Attention cGAN</h2><p>A paired restoration GAN with attention-gated U-Net skips, designed to emphasize useful structures in the cloudy input.</p><div className="gan-flow"><span>Cloudy input</span><i>→</i><span>Attention U-Net</span><i>→</i><span>Clear estimate</span></div><p className="gan-detail"><b>Training:</b> uses the same aligned pairs and adversarial plus L1 objective.</p><code>.venv/bin/python src/train_attention_gan.py --epochs 20</code><small>Checkpoint: models/attention_gan_best.pth</small></section></div>
        <div className="gan-note"><b>Use aligned pairs.</b> Cloudy and clear TIFFs must show the same location and be pixel-aligned. Both outputs are estimates; details hidden by clouds cannot be verified from the input alone.</div>
      </section>}
    </main>
  </div>;
}
export default App;
