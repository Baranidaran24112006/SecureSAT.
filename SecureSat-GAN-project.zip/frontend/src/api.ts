import type { GanResult, GanStatuses, ModelStatus, Restoration, Sample, Validation } from './types';

const base = (import.meta.env.VITE_API_URL as string | undefined) ?? 'http://127.0.0.1:8000';
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(`${base}${path}`, init); }
  catch { throw new Error('Cannot reach the local API. Start the backend and retry.'); }
  if (!response.ok) {
    let message = `Request failed (${response.status}).`;
    try { const body = await response.json() as { detail?: string }; if (body.detail) message = body.detail; } catch { /* keep the safe generic message */ }
    throw new Error(message);
  }
  return response.json() as Promise<T>;
}
export const api = {
  health: () => request<{ status: string; device: string }>('/api/health'),
  model: () => request<ModelStatus>('/api/model'),
  samples: () => request<{ samples: Sample[] }>('/api/samples'),
  samplePreview: (name: string, stretch: string) => request<Validation>(`/api/samples/${encodeURIComponent(name)}/preview?stretch=${stretch}`),
  validate: (file: File, stretch: string) => { const body = new FormData(); body.append('file', file); return request<Validation>(`/api/validate?stretch=${stretch}`, { method: 'POST', body }); },
  restore: (file: File | null, sample: string | null, stretch: string) => {
    const body = new FormData(); if (file) body.append('file', file); if (sample) body.append('sample', sample); body.append('stretch', stretch);
    return request<Restoration>('/api/restore', { method: 'POST', body });
  },
  conditionalGan: (file: File | null, sample: string | null, stretch: string) => {
    const body = new FormData(); if (file) body.append('file', file); if (sample) body.append('sample', sample); body.append('stretch', stretch);
    return request<GanResult>('/api/gan/conditional', { method: 'POST', body });
  },
  ganStatus: () => request<GanStatuses>('/api/gan/status'),
  attentionGan: (file: File | null, sample: string | null, stretch: string) => {
    const body = new FormData(); if (file) body.append('file', file); if (sample) body.append('sample', sample); body.append('stretch', stretch);
    return request<GanResult>('/api/gan/attention', { method: 'POST', body });
  },
  verify: (sha256: string, expected_sha256?: string) => request<{ sha256: string; matches_expected: boolean | null; meaning: string }>('/api/integrity/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sha256, expected_sha256 }) }),
};
