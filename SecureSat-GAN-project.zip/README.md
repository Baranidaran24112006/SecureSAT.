# SecureSat-GAN

A local satellite-image restoration workspace with a trained reflectance U-Net baseline and paired cloudy-to-clear GAN options: Pix2Pix and Attention cGAN.

## Start the application

From the project root:

```bash
.venv/bin/uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000` and keep the server terminal running. See [docs/RUNNING.md](docs/RUNNING.md) for details.

## GAN examples

Open the **GAN concepts** page in the app, or read [docs/GAN_GUIDE.md](docs/GAN_GUIDE.md) for the model differences and training commands. The [project flowchart](docs/FLOWCHART.md) shows how the data, models, and app fit together.

| Model | Input during inference | Data requirement | Project example |
|---|---|---|---|
| Pix2Pix GAN | Cloudy image | Matched cloudy/clear pairs | Translate a cloudy patch to a clear estimate |
| Attention cGAN | Cloudy image | Matched cloudy/clear pairs | Paired translation with attention-gated U-Net skip connections |

Examples after training:

```bash
.venv/bin/python src/predict_conditional_gan.py --input data/raw/cloudy/pair_001.tif
```

Train the second paired model with `.venv/bin/python src/train_attention_gan.py --epochs 20` before using its app option.

The production restoration screen currently uses `models/generator_reflectance_best.pth`, a supervised U-Net checkpoint. The GAN examples train separate checkpoints; they do not silently replace that production model.

## Data and scientific limits

The model reads bands 4/3/2 from 256×256 GeoTIFFs, scales reflectance by 10,000, and predicts a 3-band RGB estimate. It is not a 13-band reconstruction. Predicted detail under clouds is an estimate, not verified ground truth. See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/PROJECT_STATUS.md](docs/PROJECT_STATUS.md).
