# Paired GANs for satellite restoration

The app now offers two models that both receive the cloudy image and learn from same-location cloudy/clear pairs.

## Pix2Pix GAN

This is the existing trained conditional GAN: a U-Net generator predicts a clear estimate, a PatchGAN discriminator judges local cloudy/output pairs, and an L1 loss encourages pixel agreement.

```bash
.venv/bin/python src/train_conditional_gan.py
.venv/bin/python src/predict_conditional_gan.py --input data/raw/cloudy/pair_001.tif
```

Checkpoint: `models/generator_gan_best.pth`.

## Attention cGAN

This paired conditional GAN uses attention gates on the U-Net skip connections so the generator can filter features that are less useful for reconstructing the scene. It retains paired adversarial and L1 training.

```bash
.venv/bin/python src/train_attention_gan.py --epochs 20
```

It saves the best validation checkpoint to `models/attention_gan_best.pth`. Training is required once before this option becomes available in the web app; CPU training may take a while.

## Data and limits

Cloudy and clear TIFFs must depict the same place and be pixel-aligned. Training with mismatched pairs teaches incorrect scene structure. Both models predict 3-band RGB from bands 4/3/2 and estimate details hidden by clouds; they do not recover verified ground truth or produce all 13 satellite bands. Check held-out clear references and validation MAE before judging model quality.

Vanilla GAN and CycleGAN are no longer part of the app because they do not fit this paired restoration task as well. Their old scripts/checkpoints remain in the repository as historical experiments, but the current UI and API do not offer them.
