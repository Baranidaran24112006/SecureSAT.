# Architecture

The legacy Streamlit application and all training/evaluation files remain in place. The new application has a Vite/React/TypeScript client in `frontend/` and a local FastAPI service in `backend/`.

The GAN page exposes paired cloudy-to-clear models only: the existing Pix2Pix-style U-Net/PatchGAN and an attention-gated U-Net cGAN. Each uses the selected cloudy scene at inference, and the attention model has a separate checkpoint trained with the same aligned cloudy/clear pairs. These GAN checkpoints are separate from the reflectance U-Net checkpoint served by the restoration screen. The older Vanilla GAN and CycleGAN experiments are no longer exposed by the app API or UI.

```text
Browser (localhost:5173)
  ├─ typed REST client → FastAPI (127.0.0.1:8000)
  ├─ GeoTIFF validation / sample allowlist / SHA-256
  └─ returned PNG previews + in-memory export downloads

FastAPI
  ├─ raster.py: GeoTIFF checks, exact 4/3/2 reflectance preprocessing,
  │             fixed or percentile rendering, 3-band georeferenced export
  └─ model.py: lazily loaded generator_reflectance_best.pth, one inference lock
```

The model tensor is produced from bands [4,3,2], divided by 10,000, clipped to [0,1], then mapped to [-1,1], matching `src/dataset_reflectance.py`. Preview stretches are separate and never feed inference. The default comparison stretch calculates 2–98 percentile limits independently for each RGB band over the cloudy input plus prediction, and includes a valid paired clear reference when one exists. Those shared limits are applied to every displayed image. The pre-inference source preview uses the cloudy-input limits; after inference, all compared images use joint limits so the same pixels use the same display mapping without clipping a darker prediction or reference to black. Fixed reflectance [0,1] and independent per-image percentile modes are also available; the independent mode can change apparent colors and brightness.

Only filenames from the server-provided sample list are accepted as sample selectors. Uploads are in-memory, capped at 64 MiB, restricted to GeoTIFF suffixes, and limited to 256×256 rasters with at least four bands. A single inference slot bounds CPU memory use. CORS permits only the local development frontend origins.

The prediction is a three-channel RGB restoration estimate. It is not a 13-band product and is not evidence that cloud-hidden details are correct. Reference MAE/PSNR are computed only for same-name clear samples with complete valid coverage, on reflectance [0,1]. Hash comparison establishes byte equality only against a digest supplied by the user.
