# Project status

## Current phase
Complete — local full-stack implementation and verification.

## Completed
- Existing Streamlit app and project scripts are preserved as the legacy entry point.
- `src/generator.py` defines the checkpoint-compatible 3-channel U-Net (features=16).
- `src/dataset_reflectance.py` confirms training input bands [4, 3, 2], scale 10000, clipping to [0,1], then mapping to [-1,1].
- `models/generator_reflectance_best.pth` loads as a 64-key state dict; its first convolution is (16,3,3,3).
- Local environment has PyTorch 2.14.1+cu130 and Rasterio 1.5.2; CPU inference remains supported.
- Dataset contains 724 cloudy TIFFs.
- New FastAPI backend provides local health/model/sample/preview/validate/restore/integrity routes, 64 MiB upload cap, 256×256/band/mask validation, one CPU inference slot and allowlisted samples.
- New renderer separates training preprocessing from PNG display, supports fixed reflectance, shared per-band input/output/reference stretches and independent per-image percentile stretches.
- Three-band uint16 GeoTIFF export retains CRS/transform and labels RGB bands. Paired samples return clear-reference image preview, MAE/PSNR and input/output SHA-256 values.
- React/TypeScript UI includes real upload/sample preview, restoration, slider and side-by-side/reference views, zoom, downloads, hashes and honest model/metric explanations.
- GAN page exposes two paired cloudy-to-clear models: Pix2Pix using the existing conditional checkpoint, and Attention cGAN with a separate training script/checkpoint and inference service. Vanilla GAN and CycleGAN are no longer exposed in the UI or API. See `docs/GAN_GUIDE.md` and `docs/FLOWCHART.md`.
- FastAPI serves the production frontend bundle at `/`; Node.js is only needed for frontend development or rebuilding, so the existing local installation can run the complete app with one Python server.
- Backend tests: 12 checks pass, including real upload validation, a saved-checkpoint restore on a paired sample, paired-reference metrics and parsed GeoTIFF export.
- TypeScript type-check and Vite production build pass. Browser manual run showed actual sample image, CPU model, output, comparison and paired metrics.

## Risks / decisions
- FastAPI and frontend dependencies were installed into the existing `.venv`/project frontend.
- No usable Git repository metadata was detected. Existing application, model, training code, datasets and outputs remain in place; the implementation was added alongside them.
- Checkpoint output is a 3-band model prediction; it cannot restore hidden detail with certainty or produce the original 13 spectral bands.
- Rendering is visualization only and must not change the normalized model tensor.

## Outstanding work
- None for the requested local application path. User can run the documented commands in `docs/RUNNING.md`.

## Next exact action
None. Start the application using the commands in `docs/RUNNING.md`.
