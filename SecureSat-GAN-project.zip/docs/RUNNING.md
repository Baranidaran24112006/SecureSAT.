# Running SecureSat-GAN locally

## Run the finished application

The project uses its existing `.venv` for PyTorch, Rasterio, NumPy and Pillow. Install the small API dependencies once if needed:

```bash
.venv/bin/pip install -r backend/requirements.txt
```

The production React build is served by FastAPI, so launch the whole application from the project root with:

```bash
.venv/bin/uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. The model loads on the first restoration request. `/api/health` confirms service status and `/api/model` reports checkpoint availability/load state.

The **GAN concepts** page compares Pix2Pix and Attention cGAN, both paired cloudy-to-clear models. Pix2Pix uses the existing checkpoint. Train the attention model with `.venv/bin/python src/train_attention_gan.py --epochs 20` before running that option. Training can take a long time on CPU. The restoration screen continues to use the existing reflectance U-Net checkpoint.

## Frontend development

To edit the React source with Vite hot reload, install Node.js 18+ and pnpm, then run:

```bash
cd frontend
pnpm dev
```

Open `http://127.0.0.1:5173`. The API base defaults to `http://127.0.0.1:8000`; set `VITE_API_URL` at frontend build time to override it. Rebuild the production files with `pnpm build` before using the single-server launch flow again.

## Checks

```bash
.venv/bin/python -m unittest backend.tests.test_raster -v
cd frontend && pnpm build
```

Images stay on the local machine. Upload limit: 64 MiB. Supported rasters: 256×256 GeoTIFFs with at least four bands and complete selected RGB coverage. The default comparison stretch calculates shared per-band 2–98 limits from the cloudy input plus prediction, and includes a paired clear reference when one exists. It applies the same mapping to every compared image. Before inference, the source preview uses input-only limits. Fixed reflectance [0,1] and independent per-image percentile modes are also available. Output is a 3-band uint16 RGB GeoTIFF with the source CRS and affine transform retained where provided. The app does not modify input files or start training.
