# SecureSat-GAN flowchart

```mermaid
flowchart TD
    Cloudy[Cloudy GeoTIFF] --> Pair[Match clear TIFF by same filename]
    Clear[Aligned clear GeoTIFF] --> Pair
    Pair --> RGB[Read RGB bands 4/3/2 and normalize reflectance]
    RGB --> PixTrain[Train Pix2Pix: U-Net + conditional PatchGAN + L1]
    RGB --> AttnTrain[Train Attention cGAN: attention U-Net + PatchGAN + L1]
    PixTrain --> PixModel[Pix2Pix checkpoint]
    AttnTrain --> AttnModel[Attention cGAN checkpoint]

    User[Select/upload cloudy GeoTIFF] --> Validate[Validate raster and prepare RGB input]
    Validate --> Pick{Choose paired restoration model}
    PixModel --> Pick
    AttnModel --> Pick
    Pick --> Estimate[Generate 3-band clear-image estimate]
    Estimate --> Preview[Compare input and estimate]
    Estimate --> Export[Download georeferenced GeoTIFF]
```

Both GANs require aligned pairs and estimate the hidden content; outputs are not verified ground truth.
