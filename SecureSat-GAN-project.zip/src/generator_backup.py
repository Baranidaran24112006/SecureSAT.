import torch
import torch.nn as nn


class UNetGenerator(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, features=16):
        super().__init__()

        self.encoder1 = self.block(in_channels, features)
        self.encoder2 = self.block(features, features * 2)
        self.encoder3 = self.block(features * 2, features * 4)
        self.encoder4 = self.block(features * 4, features * 8)

        self.pool = nn.MaxPool2d(2)
        self.bottleneck = self.block(features * 8, features * 16)

        self.up4 = nn.ConvTranspose2d(features * 16, features * 8, 2, 2)
        self.decoder4 = self.block(features * 16, features * 8)

        self.up3 = nn.ConvTranspose2d(features * 8, features * 4, 2, 2)
        self.decoder3 = self.block(features * 8, features * 4)

        self.up2 = nn.ConvTranspose2d(features * 4, features * 2, 2, 2)
        self.decoder2 = self.block(features * 4, features * 2)

        self.up1 = nn.ConvTranspose2d(features * 2, features, 2, 2)
        self.decoder1 = self.block(features * 2, features)

        self.output = nn.Sequential(
            nn.Conv2d(features, out_channels, kernel_size=1),
            nn.Tanh()
        )

    @staticmethod
    def block(in_channels, out_channels):
        groups = min(8, out_channels)
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.GroupNorm(groups, out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.GroupNorm(groups, out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        e1 = self.encoder1(x)
        e2 = self.encoder2(self.pool(e1))
        e3 = self.encoder3(self.pool(e2))
        e4 = self.encoder4(self.pool(e3))

        b = self.bottleneck(self.pool(e4))

        d4 = self.decoder4(torch.cat((self.up4(b), e4), dim=1))
        d3 = self.decoder3(torch.cat((self.up3(d4), e3), dim=1))
        d2 = self.decoder2(torch.cat((self.up2(d3), e2), dim=1))
        d1 = self.decoder1(torch.cat((self.up1(d2), e1), dim=1))

        return self.output(d1)
