from pathlib import Path
import re
import subprocess
import tempfile
import shutil

ROOT = Path.home() / "SecureSat-GAN"
DOWNLOADS = Path.home() / "Downloads"

CLOUDY_ARCHIVE = DOWNLOADS / "ROIs2017_winter_s2_cloudy.tar.gz"
CLEAR_ARCHIVE = DOWNLOADS / "ROIs2017_winter_s2.tar.gz"

CLOUDY_PREFIX = "ROIs2017_winter_s2_cloudy/s2_cloudy_102"
CLEAR_PREFIX = "ROIs2017_winter_s2/s2_102"

def list_archive(archive):
    result = subprocess.run(
        ["tar", "-tzf", str(archive)],
        check=True, capture_output=True, text=True
    )
    return result.stdout.splitlines()

def find_ids(names, prefix, pattern):
    regex = re.compile(pattern)
    ids = set()
    for name in names:
        if name.startswith(prefix + "/"):
            match = regex.fullmatch(Path(name).name)
            if match:
                ids.add(int(match.group(1)))
    return ids

def main():
    for archive in (CLOUDY_ARCHIVE, CLEAR_ARCHIVE):
        if not archive.is_file():
            raise FileNotFoundError(f"Archive not found: {archive}")

    print("Scanning cloudy archive...", flush=True)
    cloudy_names = list_archive(CLOUDY_ARCHIVE)
    print("Scanning clear archive...", flush=True)
    clear_names = list_archive(CLEAR_ARCHIVE)

    cloudy_ids = find_ids(
        cloudy_names, CLOUDY_PREFIX,
        r"ROIs2017_winter_s2_cloudy_102_p(\d+)\.tif"
    )
    clear_ids = find_ids(
        clear_names, CLEAR_PREFIX,
        r"ROIs2017_winter_s2_102_p(\d+)\.tif"
    )
    ids = sorted(cloudy_ids & clear_ids)

    print("Cloudy files:", len(cloudy_ids))
    print("Clear files:", len(clear_ids))
    print("Matching pairs:", len(ids))

    # The original six pairs already represent patch IDs 100-105.
    new_ids = [i for i in ids if i not in range(100, 106)]
    cloudy_out = ROOT / "data/raw/cloudy"
    clear_out = ROOT / "data/raw/clear"
    cloudy_out.mkdir(parents=True, exist_ok=True)
    clear_out.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="securesat_") as temp:
        temp = Path(temp)
        ctemp, rtemp = temp / "cloudy", temp / "clear"
        ctemp.mkdir()
        rtemp.mkdir()

        c_members = [
            f"{CLOUDY_PREFIX}/ROIs2017_winter_s2_cloudy_102_p{i}.tif"
            for i in new_ids
        ]
        r_members = [
            f"{CLEAR_PREFIX}/ROIs2017_winter_s2_102_p{i}.tif"
            for i in new_ids
        ]

        if new_ids:
            print(f"Extracting {len(new_ids)} additional cloudy images...", flush=True)
            subprocess.run(
                ["tar", "-xzf", str(CLOUDY_ARCHIVE), "-C", str(ctemp), *c_members],
                check=True
            )
            print(f"Extracting {len(new_ids)} additional clear images...", flush=True)
            subprocess.run(
                ["tar", "-xzf", str(CLEAR_ARCHIVE), "-C", str(rtemp), *r_members],
                check=True
            )

        for i in new_ids:
            csrc = ctemp / CLOUDY_PREFIX / f"ROIs2017_winter_s2_cloudy_102_p{i}.tif"
            rsrc = rtemp / CLEAR_PREFIX / f"ROIs2017_winter_s2_102_p{i}.tif"
            if not csrc.is_file() or not rsrc.is_file():
                raise FileNotFoundError(f"Missing pair {i}")
            shutil.copy2(csrc, cloudy_out / f"patch_{i:03}.tif")
            shutil.copy2(rsrc, clear_out / f"patch_{i:03}.tif")

    print("Extraction complete. Original six pairs preserved.")

if __name__ == "__main__":
    main()
