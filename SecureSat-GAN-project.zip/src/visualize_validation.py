
import os
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator


CLOUDY_DIR = "data/raw/cloudy"
CLEAR_DIR = "data/raw/clear"
CHECKPOINT = "models/generator_reflectance_best.pth"
METRICS_CSV = "outputs/reflectance_validation_metrics.csv"
OUTPUT_IMAGE = "outputs/worst_validation_examples.png"

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def denormalize(tensor):
    return ((tensor.detach().cpu().float().clamp(-1, 1) + 1) / 2).numpy()


def display_rgb(tensor):
    image = np.transpose(denormalize(tensor), (1, 2, 0))

    # Independent stretch for visual inspection only.
    low = np.percentile(image, 2, axis=(0, 1), keepdims=True)
    high = np.percentile(image, 98, axis=(0, 1), keepdims=True)

    image = (image - low) / np.maximum(high - low, 1e-6)
    return np.clip(image, 0, 1)


def main():
    os.makedirs("outputs", exist_ok=True)

    dataset = SatelliteReflectanceDataset(
        cloudy_dir=CLOUDY_DIR,
        clear_dir=CLEAR_DIR,
    )

    metrics = pd.read_csv(METRICS_CSV)
    worst = metrics.nlargest(5, "output_mae")

    model = UNetGenerator(features=16).to(DEVICE)
    state = torch.load(
        CHECKPOINT,
        map_location=DEVICE,
        weights_only=True,
    )

    if isinstance(state, dict):
        if "state_dict" in state:
            state = state["state_dict"]
        elif "model_state_dict" in state:
            state = state["model_state_dict"]

    model.load_state_dict(state)
    model.eval()

    fig, axes = plt.subplots(5, 4, figsize=(16, 19))

    column_titles = [
        "Cloudy Input",
        "Clear Reference",
        "U-Net Prediction",
        "Absolute Error",
    ]

    for col, title in enumerate(column_titles):
        axes[0, col].set_title(title, fontsize=12)

    with torch.inference_mode():
        for row, (_, record) in enumerate(worst.iterrows()):
            index = int(record["dataset_index"])
            cloudy, clear = dataset[index]

            prediction = model(
                cloudy.unsqueeze(0).to(DEVICE)
            ).squeeze(0).cpu()

            cloudy_rgb = display_rgb(cloudy)
            clear_rgb = display_rgb(clear)
            prediction_rgb = display_rgb(prediction)

            # Absolute reflectance error, averaged over RGB channels.
            error = np.mean(
                np.abs(denormalize(prediction) -
                       denormalize(clear)),
                axis=0,
            )

            axes[row, 0].imshow(cloudy_rgb)
            axes[row, 1].imshow(clear_rgb)
            axes[row, 2].imshow(prediction_rgb)
            axes[row, 3].imshow(error, cmap="magma", vmin=0, vmax=0.05)

            axes[row, 0].set_ylabel(
                f"Index {index}\nMAE {record['output_mae']:.4f}",
                fontsize=10,
            )

            for col in range(4):
                axes[row, col].axis("off")

    fig.suptitle(
        "SecureSat-GAN: Five Hardest Validation Examples",
        fontsize=15,
    )
    plt.tight_layout()
    plt.savefig(OUTPUT_IMAGE, dpi=160, bbox_inches="tight")
    plt.close(fig)

    print(f"Saved: {OUTPUT_IMAGE}")


if __name__ == "__main__":
    main()

