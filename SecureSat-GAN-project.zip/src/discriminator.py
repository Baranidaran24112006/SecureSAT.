
import torch
import torch.nn as nn


class PatchGANDiscriminator(nn.Module):
    def __init__(self, in_channels=6, features=32):
        super().__init__()

        self.model = nn.Sequential(
            nn.Conv2d(in_channels, features, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(features, features * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(features * 2),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(features * 2, features * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(features * 4),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(features * 4, features * 8, 4, 1, 1, bias=False),
            nn.BatchNorm2d(features * 8),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(features * 8, 1, 4, 1, 1)
        )

    def forward(self, cloudy, candidate):
        x = torch.cat((cloudy, candidate), dim=1)
        return self.model(x)


if __name__ == "__main__":
    cloudy = torch.randn(1, 3, 256, 256)
    candidate = torch.randn(1, 3, 256, 256)

    discriminator = PatchGANDiscriminator(features=16)
    prediction = discriminator(cloudy, candidate)

    print("Cloudy image:", cloudy.shape)
    print("Candidate image:", candidate.shape)
    print("Discriminator output:", prediction.shape)
    print(
        "Parameters:",
        sum(p.numel() for p in discriminator.parameters())
    )
