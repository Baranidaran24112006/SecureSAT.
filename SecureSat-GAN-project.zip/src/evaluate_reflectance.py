
import os
import numpy as np
import pandas as pd
import torch

from torch.utils.data import random_split
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator


CLOUDY_DIR = "data/raw/cloudy"
CLEAR_DIR = "data/raw/clear"
CHECKPOINT = "models/generator_reflectance_best.pth"
OUTPUT_CSV = "outputs/reflectance_validation_metrics.csv"
SEED = 42

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def metrics(prediction, reference):
    prediction = prediction.detach().cpu().float().clamp(-1, 1)
    reference = reference.detach().cpu().float().clamp(-1, 1)

    pred = ((prediction + 1) / 2).numpy()
    ref = ((reference + 1) / 2).numpy()

    mae = float(np.mean(np.abs(pred - ref)))
    psnr = float(peak_signal_noise_ratio(ref, pred, data_range=1.0))

    pred = np.transpose(pred, (1, 2, 0))
    ref = np.transpose(ref, (1, 2, 0))

    ssim_values = [
        structural_similarity(
            ref[:, :, c],
            pred[:, :, c],
            data_range=1.0,
        )
        for c in range(3)
    ]

    return mae, psnr, float(np.mean(ssim_values))


def main():
    os.makedirs("outputs", exist_ok=True)

    if not os.path.isfile(CHECKPOINT):
        raise FileNotFoundError(f"Checkpoint not found: {CHECKPOINT}")

    dataset = SatelliteReflectanceDataset(
        cloudy_dir=CLOUDY_DIR,
        clear_dir=CLEAR_DIR,
    )

    generator = torch.Generator().manual_seed(SEED)
    val_size = max(1, int(len(dataset) * 0.2))
    train_size = len(dataset) - val_size

    _, val_dataset = random_split(
        dataset,
        [train_size, val_size],
        generator=generator,
    )

    model = UNetGenerator(features=16).to(DEVICE)

    state = torch.load(
        CHECKPOINT,
        map_location=DEVICE,
        weights_only=True,
    )

    if isinstance(state, dict):
        if "state_dict" in state:
            state = state["state_dict"]
        elif "model_state_dict" in state:
            state = state["model_state_dict"]

    model.load_state_dict(state)
    model.eval()

    rows = []

    print("=" * 65)
    print("SecureSat-GAN | Reflectance U-Net Validation")
    print("=" * 65)
    print(f"Total paired images: {len(dataset)}")
    print(f"Validation images: {len(val_dataset)}")
    print(f"Device: {DEVICE}")

    with torch.inference_mode():
        for position, dataset_index in enumerate(val_dataset.indices, 1):
            cloudy, clear = dataset[dataset_index]

            prediction = model(
                cloudy.unsqueeze(0).to(DEVICE)
            ).squeeze(0).cpu()

            input_mae, input_psnr, input_ssim = metrics(cloudy, clear)
            pred_mae, pred_psnr, pred_ssim = metrics(prediction, clear)

            rows.append({
                "dataset_index": dataset_index,
                "input_mae": input_mae,
                "output_mae": pred_mae,
                "input_psnr": input_psnr,
                "output_psnr": pred_psnr,
                "input_ssim": input_ssim,
                "output_ssim": pred_ssim,
            })

            if position % 20 == 0 or position == len(val_dataset):
                print(f"Evaluated {position}/{len(val_dataset)} images")

    df = pd.DataFrame(rows)
    df.to_csv(OUTPUT_CSV, index=False)

    print("\nMean validation metrics")
    print("-" * 65)

    for metric in ["mae", "psnr", "ssim"]:
        input_mean = df[f"input_{metric}"].mean()
        output_mean = df[f"output_{metric}"].mean()

        print(
            f"{metric.upper():<10} "
            f"Cloudy input: {input_mean:.6f} | "
            f"U-Net output: {output_mean:.6f}"
        )

    mae_improved = (
        df["output_mae"].mean() < df["input_mae"].mean()
    )
    psnr_improved = (
        df["output_psnr"].mean() > df["input_psnr"].mean()
    )
    ssim_improved = (
        df["output_ssim"].mean() > df["input_ssim"].mean()
    )

    print("\nImprovement over cloudy input:")
    print(f"MAE:  {'Yes' if mae_improved else 'No'}")
    print(f"PSNR: {'Yes' if psnr_improved else 'No'}")
    print(f"SSIM: {'Yes' if ssim_improved else 'No'}")

    print(f"\nDetailed results saved to: {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
