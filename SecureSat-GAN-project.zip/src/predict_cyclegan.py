"""Translate one cloudy TIFF with a trained CycleGAN cloudy-to-clear generator."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend.services.raster import export_geotiff, read_raster  # noqa: E402
from gan_models import CycleGenerator  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a trained CycleGAN on one 256x256 cloudy GeoTIFF.")
    parser.add_argument("--input", type=Path, required=True, help="Input cloudy TIFF.")
    parser.add_argument("--checkpoint", type=Path, default=ROOT / "models/cyclegan_v2_best.pth")
    parser.add_argument("--output", type=Path, default=None, help="Output TIFF path; defaults to restored_<input-name>.")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    if not args.input.is_file():
        parser.error(f"Input file does not exist: {args.input}")
    if not args.checkpoint.is_file():
        parser.error(f"Checkpoint does not exist: {args.checkpoint}. Train CycleGAN first.")
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        if args.device == "cuda" and not torch.cuda.is_available():
            parser.error("CUDA was requested but is not available.")
        device = torch.device(args.device)

    rgb, profile, invalid = read_raster(args.input.read_bytes())
    if invalid.any():
        parser.error(f"Input contains {int(invalid.sum())} masked RGB pixels.")
    state = torch.load(args.checkpoint, map_location=device, weights_only=True)
    if state.get("architecture_version") != 2:
        parser.error("This is an older checkpoint. Retrain with the updated CycleGAN first; it saves models/cyclegan_v2_best.pth.")
    generator = CycleGenerator(base_channels=state["base_channels"],
                               residual_blocks=state["residual_blocks"]).to(device)
    generator.load_state_dict(state["G_AB"], strict=True)
    generator.eval()
    tensor = torch.from_numpy(rgb * 2.0 - 1.0).unsqueeze(0).to(device)
    with torch.inference_mode():
        prediction = ((generator(tensor).squeeze(0).cpu().numpy() + 1.0) / 2.0).clip(0.0, 1.0)
    output = args.output or args.input.with_name(f"restored_{args.input.stem}.tif")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(export_geotiff(prediction, profile))
    print(f"Saved 3-band restored estimate: {output}")
    print(f"Device: {device}; source CRS: {profile.get('crs') or 'not defined'}")
    print("The translated image is a model estimate, not verified ground truth.")


if __name__ == "__main__":
    main()
