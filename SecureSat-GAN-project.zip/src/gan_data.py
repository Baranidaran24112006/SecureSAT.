"""Float-preserving RGB datasets for the standalone GAN demonstrations."""
from __future__ import annotations

import random
from pathlib import Path

import numpy as np
import rasterio
import torch
from torch.utils.data import Dataset


def load_rgb(path: Path, scale: float = 10000.0) -> torch.Tensor:
    with rasterio.open(path) as source:
        if source.count < 4:
            raise ValueError(f"{path.name}: expected at least four bands, found {source.count}.")
        if (source.height, source.width) != (256, 256):
            raise ValueError(f"{path.name}: expected 256x256, found {source.width}x{source.height}.")
        values = source.read([4, 3, 2], masked=True)
    data = np.asarray(values.filled(0), dtype=np.float32)
    if np.ma.getmaskarray(values).any() or not np.isfinite(data).all():
        raise ValueError(f"{path.name}: selected RGB bands contain invalid pixels.")
    reflectance = np.clip(data / np.float32(scale), 0.0, 1.0)
    return torch.from_numpy((reflectance * 2.0 - 1.0).copy())


def image_files(folder: str | Path) -> list[Path]:
    root = Path(folder)
    return sorted([*root.glob("*.tif"), *root.glob("*.tiff")])


class SatelliteImageDataset(Dataset[torch.Tensor]):
    """Unconditional real-image dataset, typically the clear domain."""

    def __init__(self, folder: str | Path, augment: bool = True):
        self.files = image_files(folder)
        self.augment = augment
        if not self.files:
            raise ValueError(f"No .tif or .tiff images found in {folder}.")

    def __len__(self) -> int:
        return len(self.files)

    def __getitem__(self, index: int) -> torch.Tensor:
        image = load_rgb(self.files[index])
        # Satellite patches are orientation-agnostic; these flips/rotations
        # enlarge the effective unconditional training set without changing pixels.
        if self.augment:
            if random.random() < 0.5:
                image = torch.flip(image, dims=(2,))
            if random.random() < 0.5:
                image = torch.flip(image, dims=(1,))
            if random.random() < 0.5:
                image = torch.rot90(image, random.randrange(4), dims=(1, 2))
        return image


class UnpairedSatelliteDataset(Dataset[tuple[torch.Tensor, torch.Tensor]]):
    """Returns independent cloudy/clear examples for CycleGAN training."""

    def __init__(self, cloudy_dir: str | Path, clear_dir: str | Path, augment: bool = True,
                 paired_reference: bool = False):
        self.cloudy = image_files(cloudy_dir)
        self.clear = image_files(clear_dir)
        self.augment = augment
        clear_by_name = {path.name: path for path in self.clear}
        self.matched = [(path, clear_by_name[path.name]) for path in self.cloudy if path.name in clear_by_name]
        self.paired_reference = paired_reference
        if not self.cloudy or not self.clear:
            raise ValueError("CycleGAN needs TIFF images in both cloudy and clear directories.")
        if paired_reference and not self.matched:
            raise ValueError("Paired supervision requires at least one same-named cloudy/clear TIFF pair.")

    def __len__(self) -> int:
        return len(self.matched) if self.paired_reference else max(len(self.cloudy), len(self.clear))

    def __getitem__(self, index: int):
        if self.paired_reference:
            cloudy, paired_clear = self.matched[index % len(self.matched)]
        else:
            cloudy, paired_clear = self.cloudy[index % len(self.cloudy)], None
        clear = random.choice(self.clear) if self.augment else self.clear[index % len(self.clear)]

        def sample_transform() -> tuple[bool, bool, int]:
            if not self.augment:
                return False, False, 0
            return random.random() < 0.5, random.random() < 0.5, random.randrange(4) if random.random() < 0.5 else 0

        def apply_transform(image: torch.Tensor, transform: tuple[bool, bool, int]) -> torch.Tensor:
            flip_h, flip_v, turns = transform
            if flip_h:
                image = torch.flip(image, dims=(2,))
            if flip_v:
                image = torch.flip(image, dims=(1,))
            return torch.rot90(image, turns, dims=(1, 2)) if turns else image

        cloudy_transform = sample_transform()
        real_a = apply_transform(load_rgb(cloudy), cloudy_transform)
        real_b = apply_transform(load_rgb(clear), sample_transform())
        if paired_clear is None:
            return real_a, real_b
        paired_b = apply_transform(load_rgb(paired_clear), cloudy_transform)
        return real_a, real_b, paired_b
