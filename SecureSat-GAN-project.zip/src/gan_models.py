"""Small GAN architectures used by the SecureSat-GAN learning examples."""
from __future__ import annotations

import torch
from torch import nn


class VanillaGenerator(nn.Module):
    """Resize-convolution generator that avoids transposed-convolution checkerboards."""

    def __init__(self, latent_dim: int = 100, base_channels: int = 32):
        super().__init__()
        if latent_dim < 1 or base_channels < 8 or base_channels % 2:
            raise ValueError("latent_dim must be positive and base_channels an even value >= 8")
        b = base_channels
        self.latent_dim = latent_dim
        layers: list[nn.Module] = [
            nn.ConvTranspose2d(latent_dim, b * 16, 4, 1, 0, bias=False),  # 4x4 seed
            nn.BatchNorm2d(b * 16), nn.ReLU(True),
        ]
        channels = (b * 16, b * 8, b * 4, b * 2, b, b // 2)
        for incoming, outgoing in zip(channels, channels[1:]):
            layers.extend([nn.Upsample(scale_factor=2, mode="nearest"),
                           nn.Conv2d(incoming, outgoing, 3, padding=1, bias=False),
                           nn.BatchNorm2d(outgoing), nn.ReLU(True)])
        layers.extend([nn.Upsample(scale_factor=2, mode="nearest"),
                       nn.Conv2d(b // 2, 3, 3, padding=1), nn.Tanh()])
        self.network = nn.Sequential(*layers)

    def forward(self, noise: torch.Tensor) -> torch.Tensor:
        if noise.ndim == 2:
            noise = noise[:, :, None, None]
        if noise.ndim != 4 or noise.shape[1:] != (self.latent_dim, 1, 1):
            raise ValueError(f"Noise must have shape (N, {self.latent_dim}) or (N, {self.latent_dim}, 1, 1).")
        return self.network(noise)


class VanillaDiscriminator(nn.Module):
    """Unconditional discriminator returning one real/fake logit per image."""

    def __init__(self, base_channels: int = 32):
        super().__init__()
        if base_channels < 8 or base_channels % 2:
            raise ValueError("base_channels must be an even value >= 8")
        b = base_channels

        from torch.nn.utils import spectral_norm

        def down(in_ch: int, out_ch: int) -> list[nn.Module]:
            return [spectral_norm(nn.Conv2d(in_ch, out_ch, 4, 2, 1)),
                    nn.LeakyReLU(0.2, inplace=True)]

        self.network = nn.Sequential(
            *down(3, b),
            *down(b, b * 2),
            *down(b * 2, b * 4),
            *down(b * 4, b * 8),
            *down(b * 8, b * 16),
            *down(b * 16, b * 16),  # 4x4
            spectral_norm(nn.Conv2d(b * 16, 1, 4, 1, 0)),
        )

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        if image.ndim != 4 or image.shape[1:] != (3, 256, 256):
            raise ValueError("VanillaDiscriminator expects an N x 3 x 256 x 256 batch.")
        return self.network(image).view(-1)


class ResidualBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.block = nn.Sequential(
            nn.ReflectionPad2d(1), nn.Conv2d(channels, channels, 3, bias=False),
            nn.InstanceNorm2d(channels), nn.ReLU(inplace=True),
            nn.ReflectionPad2d(1), nn.Conv2d(channels, channels, 3, bias=False),
            nn.InstanceNorm2d(channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.block(x)


class CycleGenerator(nn.Module):
    """ResNet translator with resize-convolution upsampling to reduce checkerboards."""

    def __init__(self, in_channels: int = 3, out_channels: int = 3, base_channels: int = 32, residual_blocks: int = 6):
        super().__init__()
        if base_channels < 8 or residual_blocks < 1:
            raise ValueError("base_channels must be >= 8 and residual_blocks must be positive")
        b = base_channels
        layers: list[nn.Module] = [
            nn.ReflectionPad2d(3), nn.Conv2d(in_channels, b, 7, bias=False),
            nn.InstanceNorm2d(b), nn.ReLU(inplace=True),
        ]
        for multiplier in (2, 4):
            previous = b * (multiplier // 2)
            current = b * multiplier
            layers.extend([
                nn.Conv2d(previous, current, 3, stride=2, padding=1, bias=False),
                nn.InstanceNorm2d(current), nn.ReLU(inplace=True),
            ])
        layers.extend(ResidualBlock(b * 4) for _ in range(residual_blocks))
        for current, following in ((b * 4, b * 2), (b * 2, b)):
            layers.extend([
                nn.Upsample(scale_factor=2, mode="nearest"),
                nn.ReflectionPad2d(1), nn.Conv2d(current, following, 3, bias=False),
                nn.InstanceNorm2d(following), nn.ReLU(inplace=True),
            ])
        layers.extend([nn.ReflectionPad2d(3), nn.Conv2d(b, out_channels, 7), nn.Tanh()])
        self.network = nn.Sequential(*layers)

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        if image.ndim != 4 or image.shape[1] != 3:
            raise ValueError("CycleGenerator expects an N x 3 x H x W RGB batch.")
        return self.network(image)


class CyclePatchDiscriminator(nn.Module):
    """Patch discriminator for one CycleGAN image domain."""

    def __init__(self, in_channels: int = 3, base_channels: int = 32):
        super().__init__()
        b = base_channels
        self.network = nn.Sequential(
            nn.Conv2d(in_channels, b, 4, 2, 1), nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(b, b * 2, 4, 2, 1, bias=False), nn.InstanceNorm2d(b * 2), nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(b * 2, b * 4, 4, 2, 1, bias=False), nn.InstanceNorm2d(b * 4), nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(b * 4, b * 8, 4, 1, 1, bias=False), nn.InstanceNorm2d(b * 8), nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(b * 8, 1, 4, 1, 1),
        )

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        return self.network(image)
