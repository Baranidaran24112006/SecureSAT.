from pathlib import Path
import csv
import random
import sys

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset, random_split

from dataset import SatelliteCloudDataset
from generator import UNetGenerator

ROOT = Path(__file__).resolve().parent.parent
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

EPOCHS = 20
BATCH_SIZE = 2
LR = 0.0002
SEED = 42
NUM_WORKERS = 0

torch.manual_seed(SEED)
random.seed(SEED)


def main():
    dataset = SatelliteCloudDataset(
        cloudy_dir=str(ROOT / "data/raw/cloudy"),
        clear_dir=str(ROOT / "data/raw/clear"),
        size=256,
    )

    val_size = max(1, int(len(dataset) * 0.2))
    train_size = len(dataset) - val_size

    train_set, val_set = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(SEED),
    )

    train_loader = DataLoader(
        train_set,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
    )
    val_loader = DataLoader(
        val_set,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
    )

    models_dir = ROOT / "models"
    outputs_dir = ROOT / "outputs"
    models_dir.mkdir(exist_ok=True)
    outputs_dir.mkdir(exist_ok=True)

    latest_path = models_dir / "generator_latest.pth"
    best_path = models_dir / "generator_best.pth"
    history_path = outputs_dir / "training_history.csv"

    generator = UNetGenerator(features=16).to(DEVICE)
    optimizer = torch.optim.Adam(generator.parameters(), lr=LR)
    criterion = nn.L1Loss()

    start_epoch = 0
    best_val = float("inf")

    if latest_path.exists():
        answer = input(
            "Existing checkpoint found. Resume it? [y/N]: "
        ).strip().lower()

        if answer == "y":
            try:
                state = torch.load(
                    latest_path, map_location=DEVICE, weights_only=True
                )
                generator.load_state_dict(state)
                print("Resumed generator weights.")
                print("Note: optimizer state and previous epoch are not restored.")
            except Exception as exc:
                print(f"Could not load checkpoint: {exc}")
                print("Starting with fresh weights.")

    print(f"Device: {DEVICE}")
    print(f"Total pairs: {len(dataset)}")
    print(f"Training pairs: {len(train_set)}")
    print(f"Validation pairs: {len(val_set)}")
    print(f"Epochs this run: {EPOCHS}")
    print(f"Batch size: {BATCH_SIZE}")

    if not history_path.exists():
        with history_path.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["epoch", "train_l1", "val_l1"])

    for epoch in range(start_epoch, EPOCHS):
        generator.train()
        train_total = 0.0
        train_count = 0

        for step, (cloudy, clear) in enumerate(train_loader, 1):
            cloudy = cloudy.to(DEVICE)
            clear = clear.to(DEVICE)

            optimizer.zero_grad(set_to_none=True)
            generated = generator(cloudy)
            loss = criterion(generated, clear)
            loss.backward()
            optimizer.step()

            train_total += loss.item() * cloudy.size(0)
            train_count += cloudy.size(0)

            if step % 50 == 0 or step == len(train_loader):
                print(
                    f"\rEpoch {epoch + 1}/{EPOCHS} "
                    f"batch {step}/{len(train_loader)} "
                    f"L1={loss.item():.4f}",
                    end="",
                    flush=True,
                )

        train_l1 = train_total / train_count

        generator.eval()
        val_total = 0.0
        val_count = 0

        with torch.no_grad():
            for cloudy, clear in val_loader:
                cloudy = cloudy.to(DEVICE)
                clear = clear.to(DEVICE)
                generated = generator(cloudy)
                loss = criterion(generated, clear)
                val_total += loss.item() * cloudy.size(0)
                val_count += cloudy.size(0)

        val_l1 = val_total / val_count
        print(
            f"\nEpoch {epoch + 1}/{EPOCHS} "
            f"train L1={train_l1:.4f} "
            f"validation L1={val_l1:.4f}"
        )

        torch.save(generator.state_dict(), latest_path)

        if val_l1 < best_val:
            best_val = val_l1
            torch.save(generator.state_dict(), best_path)
            print(f"Saved best checkpoint (val L1={best_val:.4f})")

        with history_path.open("a", newline="") as f:
            csv.writer(f).writerow(
                [epoch + 1, f"{train_l1:.6f}", f"{val_l1:.6f}"]
            )

    print("\nTraining run finished.")
    print(f"Latest model: {latest_path}")
    print(f"Best model:   {best_path}")
    print(f"Loss history: {history_path}")


if __name__ == "__main__":
    main()
