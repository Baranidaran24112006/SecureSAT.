"""Generate new unconditional satellite-like RGB samples from a trained Vanilla GAN."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from gan_models import VanillaGenerator

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description="Sample new images from a trained Vanilla GAN checkpoint.")
    parser.add_argument("--checkpoint", type=Path, default=ROOT / "models/vanilla_gan_v2.pth")
    parser.add_argument("--count", type=int, default=16, help="Number of images to generate (default: 16).")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/vanilla_gan/generated.png",
                        help="Path for the contact sheet; individual PNGs are saved beside it.")
    parser.add_argument("--seed", type=int, default=None, help="Optional seed to reproduce the same samples.")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    if args.count < 1:
        parser.error("--count must be at least 1")
    if not args.checkpoint.is_file():
        parser.error(f"Checkpoint not found: {args.checkpoint}. Train Vanilla GAN first.")
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA was requested but is not available.")
    device = torch.device("cuda" if args.device == "auto" and torch.cuda.is_available()
                          else "cpu" if args.device == "auto" else args.device)
    if args.seed is not None:
        torch.manual_seed(args.seed)

    state = torch.load(args.checkpoint, map_location=device, weights_only=True)
    if state.get("architecture_version") != 2:
        parser.error("This is an older checkpoint. Train the updated Vanilla GAN first; it saves models/vanilla_gan_v2.pth.")
    latent_dim = int(state["latent_dim"])
    generator = VanillaGenerator(latent_dim=latent_dim, base_channels=int(state["base_channels"])).to(device)
    generator.load_state_dict(state["generator"], strict=True)
    generator.eval()
    with torch.inference_mode():
        generated = generator(torch.randn(args.count, latent_dim, device=device)).cpu()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    columns = min(4, args.count)
    rows = (args.count + columns - 1) // columns
    sheet = Image.new("RGB", (columns * 256, rows * 256), "black")
    stem = args.output.stem
    for i, tensor in enumerate(generated):
        # Satellite reflectance is usually far below display-white. Apply a
        # per-image display stretch so previews are visible without changing
        # the model's generated values or pretending these PNGs are GeoTIFFs.
        rgb = ((tensor.clamp(-1, 1) + 1) / 2).permute(1, 2, 0).numpy()
        display = np.empty_like(rgb)
        for channel in range(3):
            low, high = np.percentile(rgb[..., channel], [2, 98])
            display[..., channel] = np.clip((rgb[..., channel] - low) / max(float(high - low), 1e-6), 0, 1)
        image = Image.fromarray((display * 255).round().astype("uint8"), "RGB")
        image.save(args.output.with_name(f"{stem}_{i + 1:02}.png"))
        sheet.paste(image, ((i % columns) * 256, (i // columns) * 256))
    sheet.save(args.output)
    print(f"Generated {args.count} new RGB images using {device}.")
    print(f"Contact sheet: {args.output}")
    print(f"Individual images: {args.output.parent}/{stem}_01.png … {stem}_{args.count:02}.png")
    print("These are unconditional samples; they do not restore a specific cloudy input.")


if __name__ == "__main__":
    main()
