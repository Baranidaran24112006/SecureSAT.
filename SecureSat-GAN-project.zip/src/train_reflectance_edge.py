
from pathlib import Path
import csv
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

SEED = 42
EPOCHS = 30
BATCH_SIZE = 2
LR = 0.0001
PATIENCE = 6
EDGE_WEIGHT = 0.05


def edge_loss(prediction, target):
    pred_dx = prediction[:, :, :, 1:] - prediction[:, :, :, :-1]
    pred_dy = prediction[:, :, 1:, :] - prediction[:, :, :-1, :]

    target_dx = target[:, :, :, 1:] - target[:, :, :, :-1]
    target_dy = target[:, :, 1:, :] - target[:, :, :-1, :]

    loss_x = F.l1_loss(pred_dx, target_dx)
    loss_y = F.l1_loss(pred_dy, target_dy)

    return (loss_x + loss_y) / 2


def main():
    torch.manual_seed(SEED)

    dataset = SatelliteReflectanceDataset(
        cloudy_dir=str(ROOT / "data/raw/cloudy"),
        clear_dir=str(ROOT / "data/raw/clear"),
        size=256,
    )

    val_size = max(1, int(len(dataset) * 0.2))
    train_size = len(dataset) - val_size

    train_set, val_set = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(SEED),
    )

    train_loader = DataLoader(
        train_set,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=0,
    )

    val_loader = DataLoader(
        val_set,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    model = UNetGenerator(features=16).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)

    models_dir = ROOT / "models"
    outputs_dir = ROOT / "outputs"
    models_dir.mkdir(exist_ok=True)
    outputs_dir.mkdir(exist_ok=True)

    best_path = models_dir / "generator_reflectance_edge_best.pth"
    latest_path = models_dir / "generator_reflectance_edge_latest.pth"
    history_path = outputs_dir / "reflectance_edge_training_history.csv"

    best_val = float("inf")
    no_improve = 0

    with history_path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "epoch",
            "train_total_loss",
            "train_l1",
            "train_edge",
            "val_l1",
            "val_edge",
            "val_total_loss",
        ])

        print(f"Device: {DEVICE}")
        print(f"Training pairs: {len(train_set)}")
        print(f"Validation pairs: {len(val_set)}")
        print(f"Edge loss weight: {EDGE_WEIGHT}")

        for epoch in range(1, EPOCHS + 1):
            model.train()
            total_sum = 0.0
            l1_sum = 0.0
            edge_sum = 0.0

            for cloudy, clear in train_loader:
                cloudy = cloudy.to(DEVICE)
                clear = clear.to(DEVICE)

                prediction = model(cloudy)
                pixel = F.l1_loss(prediction, clear)
                edges = edge_loss(prediction, clear)
                loss = pixel + EDGE_WEIGHT * edges

                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()

                total_sum += loss.item()
                l1_sum += pixel.item()
                edge_sum += edges.item()

            train_total = total_sum / len(train_loader)
            train_l1 = l1_sum / len(train_loader)
            train_edge = edge_sum / len(train_loader)

            model.eval()
            val_l1_sum = 0.0
            val_edge_sum = 0.0
            val_total_sum = 0.0

            with torch.inference_mode():
                for cloudy, clear in val_loader:
                    cloudy = cloudy.to(DEVICE)
                    clear = clear.to(DEVICE)

                    prediction = model(cloudy)
                    pixel = F.l1_loss(prediction, clear)
                    edges = edge_loss(prediction, clear)
                    loss = pixel + EDGE_WEIGHT * edges

                    val_l1_sum += pixel.item()
                    val_edge_sum += edges.item()
                    val_total_sum += loss.item()

            val_l1 = val_l1_sum / len(val_loader)
            val_edge = val_edge_sum / len(val_loader)
            val_total = val_total_sum / len(val_loader)

            torch.save(model.state_dict(), latest_path)

            if val_total < best_val:
                best_val = val_total
                no_improve = 0
                torch.save(model.state_dict(), best_path)
                status = "best saved"
            else:
                no_improve += 1
                status = f"no improvement {no_improve}/{PATIENCE}"

            writer.writerow([
                epoch,
                train_total,
                train_l1,
                train_edge,
                val_l1,
                val_edge,
                val_total,
            ])
            f.flush()

            print(
                f"Epoch {epoch:02d}/{EPOCHS} | "
                f"train L1={train_l1:.6f} | "
                f"train edge={train_edge:.6f} | "
                f"val L1={val_l1:.6f} | "
                f"val edge={val_edge:.6f} | "
                f"val total={val_total:.6f} | {status}",
                flush=True,
            )

            if no_improve >= PATIENCE:
                print("Early stopping.")
                break

    print(f"Best checkpoint: {best_path}")
    print(f"Training history: {history_path}")


if __name__ == "__main__":
    main()
