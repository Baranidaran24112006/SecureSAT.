
from pathlib import Path
import subprocess
import tempfile
import shutil

PROJECT = Path.home() / "SecureSat-GAN"
DOWNLOADS = Path.home() / "Downloads"
ID_FILE = Path("/tmp/securesat_matching_ids.txt")

CLOUDY_ARCHIVE = DOWNLOADS / "ROIs2017_winter_s2_cloudy.tar.gz"
CLEAR_ARCHIVE = DOWNLOADS / "ROIs2017_winter_s2.tar.gz"

CLOUDY_PREFIX = "ROIs2017_winter_s2_cloudy/s2_cloudy_102"
CLEAR_PREFIX = "ROIs2017_winter_s2/s2_102"


def extract_members(archive, members, destination):
    subprocess.run(
        ["tar", "-xzf", str(archive), "-C", str(destination), *members],
        check=True
    )


def main():
    if not ID_FILE.is_file():
        raise FileNotFoundError(f"Missing verified ID list: {ID_FILE}")

    ids = sorted({
        int(line.strip())
        for line in ID_FILE.read_text().splitlines()
        if line.strip().isdigit()
    })

    if not ids:
        raise ValueError("No patch IDs found.")

    for archive in (CLOUDY_ARCHIVE, CLEAR_ARCHIVE):
        if not archive.is_file():
            raise FileNotFoundError(archive)

    cloudy_out = PROJECT / "data/raw/cloudy"
    clear_out = PROJECT / "data/raw/clear"
    cloudy_out.mkdir(parents=True, exist_ok=True)
    clear_out.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="securesat_") as tmp:
        tmp = Path(tmp)
        cloudy_tmp = tmp / "cloudy"
        clear_tmp = tmp / "clear"
        cloudy_tmp.mkdir()
        clear_tmp.mkdir()

        cloudy_members = [
            f"{CLOUDY_PREFIX}/ROIs2017_winter_s2_cloudy_102_p{i}.tif"
            for i in ids
        ]
        clear_members = [
            f"{CLEAR_PREFIX}/ROIs2017_winter_s2_102_p{i}.tif"
            for i in ids
        ]

        print(f"Extracting {len(ids)} cloudy patches...")
        extract_members(CLOUDY_ARCHIVE, cloudy_members, cloudy_tmp)

        print(f"Extracting {len(ids)} clear patches...")
        extract_members(CLEAR_ARCHIVE, clear_members, clear_tmp)

        for i in ids:
            cloudy_source = (
                cloudy_tmp / CLOUDY_PREFIX /
                f"ROIs2017_winter_s2_cloudy_102_p{i}.tif"
            )
            clear_source = (
                clear_tmp / CLEAR_PREFIX /
                f"ROIs2017_winter_s2_102_p{i}.tif"
            )

            if not cloudy_source.is_file() or not clear_source.is_file():
                raise FileNotFoundError(f"Missing extracted patch {i}")

            shutil.copy2(cloudy_source, cloudy_out / f"patch_{i:03}.tif")
            shutil.copy2(clear_source, clear_out / f"patch_{i:03}.tif")
            print(f"Prepared patch {i}")

    print(f"Done: processed {len(ids)} matching patch IDs.")
    print("Original pair_001.tif through pair_006.tif were preserved.")


if __name__ == "__main__":
    main()
