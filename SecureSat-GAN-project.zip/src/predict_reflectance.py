
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator


CLOUDY_DIR = "data/raw/cloudy"
CLEAR_DIR = "data/raw/clear"
CHECKPOINT = "models/generator_reflectance_best.pth"
OUTPUT_DIR = "outputs"
OUTPUT_IMAGE = os.path.join(
    OUTPUT_DIR, "reflectance_comparison_fixed.png"
)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def denormalize(tensor):
    """Convert normalized values [-1, 1] to [0, 1]."""
    return (tensor.detach().cpu().float().clamp(-1, 1) + 1) / 2


def to_display(tensor):
    """Apply a robust per-image RGB stretch for visualization."""
    image = denormalize(tensor).permute(1, 2, 0).numpy()

    low = np.percentile(image, 2, axis=(0, 1), keepdims=True)
    high = np.percentile(image, 98, axis=(0, 1), keepdims=True)

    image = (image - low) / np.maximum(high - low, 1e-6)
    return np.clip(image, 0, 1)


def calculate_metrics(prediction, reference):
    """Calculate MAE, PSNR, and mean channel-wise SSIM."""
    pred = denormalize(prediction).numpy()
    target = denormalize(reference).numpy()

    mae = float(np.mean(np.abs(pred - target)))
    psnr = float(
        peak_signal_noise_ratio(target, pred, data_range=1.0)
    )

    pred_rgb = np.transpose(pred, (1, 2, 0))
    target_rgb = np.transpose(target, (1, 2, 0))

    ssim_values = []

    for channel in range(3):
        score = structural_similarity(
            target_rgb[:, :, channel],
            pred_rgb[:, :, channel],
            data_range=1.0,
        )
        ssim_values.append(score)

    return mae, psnr, float(np.mean(ssim_values))


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not os.path.isfile(CHECKPOINT):
        raise FileNotFoundError(
            f"Model checkpoint not found: {CHECKPOINT}"
        )

    print("=" * 60)
    print("SecureSat-GAN | Reflectance U-Net Prediction")
    print("=" * 60)
    print(f"Device: {DEVICE}")

    dataset = SatelliteReflectanceDataset(
        cloudy_dir=CLOUDY_DIR,
        clear_dir=CLEAR_DIR,
    )

    print(f"Matched cloudy/clear pairs: {len(dataset)}")

    model = UNetGenerator(features=16).to(DEVICE)

    checkpoint = torch.load(
        CHECKPOINT,
        map_location=DEVICE,
        weights_only=True,
    )

    if isinstance(checkpoint, dict):
        if "state_dict" in checkpoint:
            checkpoint = checkpoint["state_dict"]
        elif "model_state_dict" in checkpoint:
            checkpoint = checkpoint["model_state_dict"]

    model.load_state_dict(checkpoint)
    model.eval()

    sample_index = 0
    cloudy, clear = dataset[sample_index]

    with torch.inference_mode():
        generated = model(
            cloudy.unsqueeze(0).to(DEVICE)
        ).squeeze(0).cpu()

    input_mae, input_psnr, input_ssim = calculate_metrics(
        cloudy, clear
    )
    output_mae, output_psnr, output_ssim = calculate_metrics(
        generated, clear
    )

    print(f"\nMetrics for sample {sample_index}")
    print("-" * 60)
    print(f"{'Metric':<14}{'Cloudy Input':>18}{'U-Net Output':>18}")
    print("-" * 60)
    print(f"{'MAE':<14}{input_mae:>18.6f}{output_mae:>18.6f}")
    print(f"{'PSNR (dB)':<14}{input_psnr:>18.3f}{output_psnr:>18.3f}")
    print(f"{'SSIM':<14}{input_ssim:>18.4f}{output_ssim:>18.4f}")

    images = [
        to_display(cloudy),
        to_display(clear),
        to_display(generated),
    ]

    titles = [
        "Cloudy Input",
        "Clear Reference",
        "Reflectance U-Net Output",
    ]

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    for ax, image, title in zip(axes, images, titles):
        ax.imshow(image)
        ax.set_title(title, fontsize=13)
        ax.axis("off")

    fig.suptitle(
        f"SecureSat-GAN - Sample {sample_index}",
        fontsize=16,
    )

    plt.tight_layout()
    plt.savefig(OUTPUT_IMAGE, dpi=180, bbox_inches="tight")
    plt.close(fig)

    print(f"\nComparison saved to: {OUTPUT_IMAGE}")
    print("Prediction completed.")


if __name__ == "__main__":
    main()
