
import hashlib
import json
from pathlib import Path

DATA_DIR = Path("data/raw")
MANIFEST = Path("outputs/integrity_manifest.json")


def calculate_sha256(file_path):
    sha256 = hashlib.sha256()

    with open(file_path, "rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            sha256.update(chunk)

    return sha256.hexdigest()


def create_manifest():
    files = sorted(
        path for path in DATA_DIR.rglob("*")
        if path.is_file() and path.suffix.lower() in {".tif", ".tiff"}
    )

    if not files:
        print("No satellite TIFF files found yet.")
        print("Download and extract the dataset, then run this again.")
        return

    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    records = {}

    for index, file_path in enumerate(files, start=1):
        relative_path = str(file_path.relative_to(DATA_DIR))
        records[relative_path] = calculate_sha256(file_path)
        print(f"[{index}/{len(files)}] Hashed: {relative_path}")

    MANIFEST.write_text(
        json.dumps(records, indent=2),
        encoding="utf-8"
    )

    print(f"\nManifest saved: {MANIFEST}")
    print(f"Files recorded: {len(records)}")


def verify_manifest():
    if not MANIFEST.exists():
        print("Manifest not found. Create it first.")
        return

    records = json.loads(MANIFEST.read_text(encoding="utf-8"))
    passed = 0
    failed = 0

    for relative_path, trusted_hash in records.items():
        file_path = DATA_DIR / relative_path

        if not file_path.is_file():
            print(f"MISSING: {relative_path}")
            failed += 1
        elif calculate_sha256(file_path) == trusted_hash:
            passed += 1
        else:
            print(f"MODIFIED: {relative_path}")
            failed += 1

    print(f"\nVerified: {passed}")
    print(f"Failed or missing: {failed}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2 or sys.argv[1] not in {"create", "verify"}:
        print("Usage: python src/integrity.py [create|verify]")
    elif sys.argv[1] == "create":
        create_manifest()
    else:
        verify_manifest()
