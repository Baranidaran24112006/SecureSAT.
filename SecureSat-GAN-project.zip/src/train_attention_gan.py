"""Train paired attention U-Net GAN for cloudy-to-clear satellite translation."""
from pathlib import Path
import argparse
import csv
import random

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from PIL import Image
import numpy as np

try:
    from .dataset import SatelliteCloudDataset
    from .generator import AttentionUNetGenerator
    from .discriminator import PatchGANDiscriminator
except ImportError:
    from dataset import SatelliteCloudDataset
    from generator import AttentionUNetGenerator
    from discriminator import PatchGANDiscriminator

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cloudy", type=Path, default=ROOT / "data/raw/cloudy")
    parser.add_argument("--clear", type=Path, default=ROOT / "data/raw/clear")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1:
        parser.error("--epochs and --batch-size must be positive")
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA was requested but is not available")
    device = torch.device("cuda" if args.device == "auto" and torch.cuda.is_available() else
                          "cpu" if args.device == "auto" else args.device)
    torch.manual_seed(42)
    random.seed(42)
    dataset = SatelliteCloudDataset(str(args.cloudy), str(args.clear), size=256)
    val_size = max(1, int(0.2 * len(dataset)))
    train_set, val_set = random_split(dataset, [len(dataset) - val_size, val_size],
                                      generator=torch.Generator().manual_seed(42))
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, num_workers=0)
    generator = AttentionUNetGenerator(features=16).to(device)
    discriminator = PatchGANDiscriminator(features=16).to(device)
    opt_g = torch.optim.Adam(generator.parameters(), lr=1e-4, betas=(0.5, 0.999))
    opt_d = torch.optim.Adam(discriminator.parameters(), lr=1e-4, betas=(0.5, 0.999))
    l1, gan = nn.L1Loss(), nn.BCEWithLogitsLoss()
    models, output = ROOT / "models", ROOT / "outputs/attention_gan"
    models.mkdir(exist_ok=True)
    output.mkdir(parents=True, exist_ok=True)
    best_path = models / "attention_gan_best.pth"
    history_path = output / "training_history.csv"
    best_val = float("inf")
    with history_path.open("w", newline="") as stream:
        csv.writer(stream).writerow(["epoch", "generator_loss", "discriminator_loss", "train_l1", "val_l1"])
    print(f"Attention cGAN | device={device} | training pairs={len(train_set)} | validation pairs={len(val_set)}")
    for epoch in range(1, args.epochs + 1):
        generator.train(); discriminator.train()
        total_g = total_d = total_l1 = 0.0
        for cloudy, clear in train_loader:
            cloudy, clear = cloudy.to(device), clear.to(device)
            with torch.no_grad():
                fake = generator(cloudy)
            d_real = discriminator(cloudy, clear)
            d_fake = discriminator(cloudy, fake)
            d_loss = 0.5 * (gan(d_real, torch.ones_like(d_real)) + gan(d_fake, torch.zeros_like(d_fake)))
            opt_d.zero_grad(set_to_none=True); d_loss.backward(); opt_d.step()
            prediction = generator(cloudy)
            reconstruction = l1(prediction, clear)
            g_loss = gan(discriminator(cloudy, prediction), torch.ones_like(d_real)) + 100.0 * reconstruction
            opt_g.zero_grad(set_to_none=True); g_loss.backward(); opt_g.step()
            total_g += g_loss.item(); total_d += d_loss.item(); total_l1 += reconstruction.item()
        generator.eval(); val_sum = 0.0
        with torch.inference_mode():
            for cloudy, clear in val_loader:
                val_sum += l1(generator(cloudy.to(device)), clear.to(device)).item()
        val_l1 = val_sum / len(val_loader)
        avg = [v / len(train_loader) for v in (total_g, total_d, total_l1)]
        with history_path.open("a", newline="") as stream:
            csv.writer(stream).writerow([epoch, *avg, val_l1])
        if val_l1 < best_val:
            best_val = val_l1
            torch.save(generator.state_dict(), best_path)
            with torch.inference_mode():
                sample = next(iter(val_loader))[0][:1].to(device)
                preview = ((generator(sample)[0].cpu().permute(1, 2, 0) + 1) * 127.5).clamp(0, 255).byte().numpy()
                Image.fromarray(np.asarray(preview, dtype=np.uint8)).save(output / "best_preview.png")
        print(f"Epoch {epoch:03}/{args.epochs} | G={avg[0]:.4f} D={avg[1]:.4f} | train L1={avg[2]:.5f} val L1={val_l1:.5f}", flush=True)
    print(f"Best attention generator: {best_path}")


if __name__ == "__main__":
    main()
