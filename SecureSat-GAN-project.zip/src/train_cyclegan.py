"""Train a CycleGAN with unpaired cloudy and clear satellite TIFF domains."""
from __future__ import annotations

import argparse
import csv
from itertools import islice
import os
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw
from torch import nn
from torch.utils.data import DataLoader, Subset, random_split

from gan_data import UnpairedSatelliteDataset
from gan_models import CycleGenerator, CyclePatchDiscriminator

ROOT = Path(__file__).resolve().parents[1]


class ReplayPool:
    """Small history pool that stabilizes discriminator updates."""

    def __init__(self, capacity: int = 50):
        self.capacity = capacity
        self.items: list[torch.Tensor] = []

    def query(self, batch: torch.Tensor) -> torch.Tensor:
        output = []
        for image in batch.detach():
            image = image.unsqueeze(0)
            if len(self.items) < self.capacity:
                self.items.append(image.clone())
                output.append(image)
            elif random.random() > 0.5:
                index = random.randrange(len(self.items))
                old = self.items[index].clone()
                self.items[index] = image.clone()
                output.append(old)
            else:
                output.append(image)
        return torch.cat(output, dim=0)


def choose_device(value: str) -> torch.device:
    if value == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if value == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available.")
    return torch.device(value)


def save_cycle_grid(a: torch.Tensor, fake_b: torch.Tensor, cycle_a: torch.Tensor,
                    b: torch.Tensor, fake_a: torch.Tensor, cycle_b: torch.Tensor, output: Path,
                    paired_b: torch.Tensor | None = None) -> None:
    tensors = [a, fake_b, cycle_a, b, fake_a, cycle_b]
    titles = ["Cloudy input", "Cloudy to clear", "Cycle back", "Clear input", "Clear to cloudy", "Cycle back"]
    if paired_b is not None:
        tensors.insert(2, paired_b)
        titles.insert(2, "Matched clear reference")
    columns = 4 if paired_b is not None else 3
    height, width = tensors[0].shape[-2:]
    tile_height = height + 20
    canvas = Image.new("RGB", (columns * width, 2 * tile_height), "#151915")
    draw = ImageDraw.Draw(canvas)
    for index, (tensor, title) in enumerate(zip(tensors, titles)):
        image = ((tensor.detach().cpu().clamp(-1, 1) + 1) / 2).permute(1, 2, 0).numpy()
        display = np.empty_like(image)
        for channel in range(3):
            low, high = np.percentile(image[..., channel], [2, 98])
            display[..., channel] = np.clip((image[..., channel] - low) / max(float(high - low), 1e-6), 0, 1)
        image = Image.fromarray((display * 255).round().astype(np.uint8), "RGB")
        x, y = (index % columns) * width, (index // columns) * tile_height
        draw.text((x + 6, y + 5), title, fill="white")
        canvas.paste(image, (x, y + 20))
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train CycleGAN using unpaired cloudy and clear TIFFs.")
    parser.add_argument("--cloudy", type=Path, default=ROOT / "data/raw/cloudy")
    parser.add_argument("--clear", type=Path, default=ROOT / "data/raw/clear")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--residual-blocks", type=int, default=6)
    parser.add_argument("--image-size", type=int, choices=(64, 128, 256), default=256,
                        help="Training tile size. 128 is a faster CPU demo; inference remains fully convolutional.")
    parser.add_argument("--steps-per-epoch", type=int, default=0,
                        help="Limit batches each epoch; 0 uses the full dataset.")
    parser.add_argument("--validation-batches", type=int, default=0,
                        help="Limit validation batches; 0 uses the full validation set.")
    parser.add_argument("--cpu-threads", type=int, default=min(4, os.cpu_count() or 1),
                        help="CPU threads used by PyTorch (default: up to 4).")
    parser.add_argument("--lambda-cycle", type=float, default=10.0)
    parser.add_argument("--lambda-identity", type=float, default=5.0)
    parser.add_argument("--paired-supervision", action="store_true",
                        help="Use same-named aligned cloudy/clear TIFFs for an extra cloudy-to-clear L1 loss.")
    parser.add_argument("--lambda-paired", type=float, default=25.0,
                        help="Weight of the aligned-pair cloudy-to-clear L1 loss when paired supervision is enabled.")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", action="store_true",
                        help="Continue from models/cyclegan_v2_latest.pth; --epochs is the number of additional epochs.")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1 or args.steps_per_epoch < 0 or args.validation_batches < 0 or args.cpu_threads < 1:
        parser.error("epochs, batch size and CPU threads must be positive; batch limits cannot be negative")

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = choose_device(args.device)
    if device.type == "cpu":
        torch.set_num_threads(args.cpu_threads)
    dataset = UnpairedSatelliteDataset(args.cloudy, args.clear, paired_reference=args.paired_supervision)
    n_val = max(1, int(0.1 * len(dataset))) if len(dataset) > 1 else 0
    n_train = len(dataset) - n_val
    if n_val:
        train_set, val_subset = random_split(dataset, [n_train, n_val], generator=torch.Generator().manual_seed(args.seed))
        validation_dataset = UnpairedSatelliteDataset(args.cloudy, args.clear, augment=False,
                                                      paired_reference=args.paired_supervision)
        val_set = Subset(validation_dataset, val_subset.indices)
    else:
        train_set, val_set = dataset, dataset
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0, drop_last=False)
    val_loader = DataLoader(val_set, batch_size=1, shuffle=False, num_workers=0)
    steps_this_epoch = min(args.steps_per_epoch, len(train_loader)) if args.steps_per_epoch else len(train_loader)
    validation_count = min(args.validation_batches, len(val_loader)) if args.validation_batches else len(val_loader)

    g_ab = CycleGenerator(base_channels=args.base_channels, residual_blocks=args.residual_blocks).to(device)
    g_ba = CycleGenerator(base_channels=args.base_channels, residual_blocks=args.residual_blocks).to(device)
    d_a = CyclePatchDiscriminator(base_channels=args.base_channels).to(device)
    d_b = CyclePatchDiscriminator(base_channels=args.base_channels).to(device)
    optimizer_g = torch.optim.Adam(list(g_ab.parameters()) + list(g_ba.parameters()), lr=2e-4, betas=(0.5, 0.999))
    optimizer_da = torch.optim.Adam(d_a.parameters(), lr=2e-4, betas=(0.5, 0.999))
    optimizer_db = torch.optim.Adam(d_b.parameters(), lr=2e-4, betas=(0.5, 0.999))
    adversarial = nn.MSELoss()  # least-squares GAN objective
    reconstruction = nn.L1Loss()
    pool_a, pool_b = ReplayPool(), ReplayPool()
    checkpoint = ROOT / "models/cyclegan_v2_best.pth"
    latest = ROOT / "models/cyclegan_v2_latest.pth"
    output_dir = ROOT / "outputs/cyclegan"
    history = output_dir / "training_history.csv"
    paired_history = output_dir / "paired_validation_history.csv"
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    best_val = float("inf")
    start_epoch = 1
    if args.resume:
        if not latest.is_file():
            parser.error(f"Cannot resume: latest checkpoint not found at {latest}")
        state = torch.load(latest, map_location=device, weights_only=True)
        if state.get("architecture_version") != 2 or state.get("base_channels") != args.base_channels or state.get("residual_blocks") != args.residual_blocks:
            parser.error("Resume checkpoint architecture does not match --base-channels/--residual-blocks. Use the same architecture as its original training run.")
        g_ab.load_state_dict(state["G_AB"], strict=True)
        g_ba.load_state_dict(state["G_BA"], strict=True)
        d_a.load_state_dict(state["D_A"], strict=True)
        d_b.load_state_dict(state["D_B"], strict=True)
        start_epoch = int(state.get("epoch", 0)) + 1
        same_objective = (bool(state.get("paired_supervision", False)) == args.paired_supervision
                          and float(state.get("lambda_paired", 25.0)) == args.lambda_paired)
        if "optimizer_g" in state and same_objective:
            optimizer_g.load_state_dict(state["optimizer_g"])
            optimizer_da.load_state_dict(state["optimizer_da"])
            optimizer_db.load_state_dict(state["optimizer_db"])
        elif "optimizer_g" in state:
            print("Training objective changed; keeping model weights but restarting optimizer history.", flush=True)
        else:
            print("Resuming weights from the existing checkpoint; optimizer history was not saved and will restart.", flush=True)
        if history.is_file():
            try:
                with history.open(newline="") as stream:
                    rows = list(csv.DictReader(stream))
                if rows:
                    best_val = min(float(row["validation_cycle_l1"]) for row in rows)
            except (KeyError, ValueError):
                best_val = float("inf")
        print(f"Resuming from epoch {start_epoch - 1}; running {args.epochs} additional epochs.", flush=True)
    else:
        with history.open("w", newline="") as stream:
            csv.writer(stream).writerow(["epoch", "generator_loss", "discriminator_loss", "validation_cycle_l1"])

    print(f"CycleGAN | device={device} | cloudy domain={len(dataset.cloudy)} | clear domain={len(dataset.clear)}", flush=True)
    print("Using unpaired domain examples for adversarial/cycle losses" +
          (" plus same-name aligned references for the cloudy-to-clear L1 loss." if args.paired_supervision else "; no matched-reference loss is enabled."), flush=True)
    if args.paired_supervision:
        print(f"Aligned same-name cloudy/clear pairs={len(dataset.matched)} | paired L1 weight={args.lambda_paired:g}.", flush=True)
        if not paired_history.is_file() or not args.resume:
            with paired_history.open("w", newline="") as stream:
                csv.writer(stream).writerow(["epoch", "heldout_paired_l1", "paired_l1_weight"])
        # Compare against the existing best checkpoint on the same fixed paired validation set.
        if args.resume and checkpoint.is_file():
            best_state = torch.load(checkpoint, map_location=device, weights_only=True)
            if best_state.get("architecture_version") == 2 and best_state.get("base_channels") == args.base_channels and best_state.get("residual_blocks") == args.residual_blocks:
                latest_ab = {key: value.detach().clone() for key, value in g_ab.state_dict().items()}
                g_ab.load_state_dict(best_state["G_AB"], strict=True)
                g_ab.eval()
                baseline_sum = 0.0
                with torch.inference_mode():
                    for batch in islice(val_loader, validation_count):
                        real_a, _, paired_b = (item.to(device) for item in batch)
                        if args.image_size != 256:
                            real_a = F.interpolate(real_a, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                            paired_b = F.interpolate(paired_b, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        baseline_sum += float(reconstruction(g_ab(real_a), paired_b))
                best_val = baseline_sum / validation_count
                g_ab.load_state_dict(latest_ab, strict=True)
                print(f"Existing best checkpoint held-out paired L1={best_val:.5f}.", flush=True)
        elif args.paired_supervision:
            best_val = float("inf")
    print(f"Training {steps_this_epoch} batches/epoch at {args.image_size}×{args.image_size}; validation batches={validation_count}.", flush=True)
    for epoch in range(start_epoch, start_epoch + args.epochs):
        g_ab.train(); g_ba.train(); d_a.train(); d_b.train()
        sum_g = sum_d = 0.0
        progress_interval = max(1, steps_this_epoch // 10)
        for step, batch in enumerate(islice(train_loader, steps_this_epoch), start=1):
            if args.paired_supervision:
                real_a, real_b, paired_b = batch
                paired_b = paired_b.to(device)
            else:
                real_a, real_b = batch
                paired_b = None
            real_a, real_b = real_a.to(device), real_b.to(device)
            if args.image_size != 256:
                real_a = F.interpolate(real_a, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                real_b = F.interpolate(real_b, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                if paired_b is not None:
                    paired_b = F.interpolate(paired_b, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)

            optimizer_g.zero_grad(set_to_none=True)
            fake_b = g_ab(real_a)
            fake_a = g_ba(real_b)
            cycle_a = g_ba(fake_b)
            cycle_b = g_ab(fake_a)
            identity_a = g_ba(real_a)
            identity_b = g_ab(real_b)
            for parameter in (*d_a.parameters(), *d_b.parameters()):
                parameter.requires_grad_(False)
            fake_b_logits = d_b(fake_b)
            fake_a_logits = d_a(fake_a)
            loss_adv = adversarial(fake_b_logits, torch.ones_like(fake_b_logits)) \
                + adversarial(fake_a_logits, torch.ones_like(fake_a_logits))
            loss_cycle = args.lambda_cycle * (reconstruction(cycle_a, real_a) + reconstruction(cycle_b, real_b))
            loss_identity = args.lambda_identity * (reconstruction(identity_a, real_a) + reconstruction(identity_b, real_b))
            loss_paired = args.lambda_paired * reconstruction(fake_b, paired_b) if paired_b is not None else 0.0
            loss_g = loss_adv + loss_cycle + loss_identity + loss_paired
            loss_g.backward()
            optimizer_g.step()
            for parameter in (*d_a.parameters(), *d_b.parameters()):
                parameter.requires_grad_(True)

            optimizer_da.zero_grad(set_to_none=True)
            pooled_a = pool_a.query(fake_a).to(device)
            real_a_logits = d_a(real_a)
            fake_a_logits = d_a(pooled_a.detach())
            loss_da = 0.5 * (adversarial(real_a_logits, torch.ones_like(real_a_logits))
                             + adversarial(fake_a_logits, torch.zeros_like(fake_a_logits)))
            loss_da.backward(); optimizer_da.step()

            optimizer_db.zero_grad(set_to_none=True)
            pooled_b = pool_b.query(fake_b).to(device)
            real_b_logits = d_b(real_b)
            fake_b_logits = d_b(pooled_b.detach())
            loss_db = 0.5 * (adversarial(real_b_logits, torch.ones_like(real_b_logits))
                             + adversarial(fake_b_logits, torch.zeros_like(fake_b_logits)))
            loss_db.backward(); optimizer_db.step()
            sum_g += float(loss_g.detach())
            sum_d += float((loss_da + loss_db).detach() * 0.5)
            if step % progress_interval == 0 or step == steps_this_epoch:
                print(f"\rEpoch {epoch:03}/{start_epoch + args.epochs - 1:03} | batch {step}/{steps_this_epoch}", end="", flush=True)

        g_ab.eval(); g_ba.eval()
        validation_sum = 0.0
        paired_validation_sum = 0.0
        with torch.inference_mode():
            for batch in islice(val_loader, validation_count):
                if args.paired_supervision:
                    real_a, real_b, paired_b = batch
                    paired_b = paired_b.to(device)
                else:
                    real_a, real_b = batch
                    paired_b = None
                real_a, real_b = real_a.to(device), real_b.to(device)
                if args.image_size != 256:
                    real_a = F.interpolate(real_a, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                    real_b = F.interpolate(real_b, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                    if paired_b is not None:
                        paired_b = F.interpolate(paired_b, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                validation_sum += float(reconstruction(g_ba(g_ab(real_a)), real_a)
                                        + reconstruction(g_ab(g_ba(real_b)), real_b))
                if paired_b is not None:
                    paired_validation_sum += float(reconstruction(g_ab(real_a), paired_b))
            validation_cycle = validation_sum / validation_count
            validation_paired = paired_validation_sum / validation_count if args.paired_supervision else None
            sample_batch = next(iter(val_loader))
            if args.paired_supervision:
                sample_a, sample_b, paired_preview = sample_batch
                paired_preview = paired_preview.to(device)
            else:
                sample_a, sample_b = sample_batch
                paired_preview = None
            sample_a, sample_b = sample_a.to(device), sample_b.to(device)
            if args.image_size != 256:
                sample_a = F.interpolate(sample_a, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                sample_b = F.interpolate(sample_b, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                if paired_preview is not None:
                    paired_preview = F.interpolate(paired_preview, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
            fake_b, fake_a = g_ab(sample_a), g_ba(sample_b)
            cycle_a, cycle_b = g_ba(fake_b), g_ab(fake_a)
        val_cycle = validation_cycle
        save_cycle_grid(sample_a[0], fake_b[0], cycle_a[0], sample_b[0], fake_a[0], cycle_b[0],
                        output_dir / f"epoch_{epoch:03}.png", paired_preview[0] if paired_preview is not None else None)
        state = {"G_AB": g_ab.state_dict(), "G_BA": g_ba.state_dict(), "D_A": d_a.state_dict(), "D_B": d_b.state_dict(),
                 "base_channels": args.base_channels, "residual_blocks": args.residual_blocks, "epoch": epoch,
                 "lambda_cycle": args.lambda_cycle, "lambda_identity": args.lambda_identity,
                 "architecture_version": 2, "image_size": args.image_size,
                 "steps_per_epoch": steps_this_epoch, "validation_cycle_l1": val_cycle,
                 "paired_supervision": args.paired_supervision, "lambda_paired": args.lambda_paired,
                 "validation_paired_l1": validation_paired,
                 "training_cloudy_images": len(dataset.cloudy), "training_clear_images": len(dataset.clear),
                 "optimizer_g": optimizer_g.state_dict(), "optimizer_da": optimizer_da.state_dict(),
                 "optimizer_db": optimizer_db.state_dict()}
        torch.save(state, latest)
        selection_metric = validation_paired if validation_paired is not None else val_cycle
        if selection_metric < best_val:
            best_val = selection_metric
            torch.save(state, checkpoint)
        with history.open("a", newline="") as stream:
            csv.writer(stream).writerow([epoch, sum_g / steps_this_epoch, sum_d / steps_this_epoch, val_cycle])
        if validation_paired is not None:
            with paired_history.open("a", newline="") as stream:
                csv.writer(stream).writerow([epoch, validation_paired, args.lambda_paired])
        paired_log = f" | held-out paired L1={validation_paired:.5f}" if validation_paired is not None else ""
        print(f"\nEpoch {epoch:03} | G={sum_g / steps_this_epoch:.4f} | D={sum_d / steps_this_epoch:.4f} | validation cycle L1={val_cycle:.5f}{paired_log} | preview={output_dir / f'epoch_{epoch:03}.png'}", flush=True)

    print(f"Best checkpoint: {checkpoint}")
    print(f"Preview grids and history: {output_dir}")


if __name__ == "__main__":
    main()
