from pathlib import Path
import csv
import sys
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset import SatelliteCloudDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEED = 42


def load_model(path):
    model = UNetGenerator(features=16).to(DEVICE)
    model.load_state_dict(torch.load(path, map_location=DEVICE, weights_only=True))
    model.eval()
    return model


def main():
    dataset = SatelliteCloudDataset()
    n_val = max(1, int(len(dataset) * 0.2))
    n_train = len(dataset) - n_val
    _, val_set = random_split(
        dataset, [n_train, n_val],
        generator=torch.Generator().manual_seed(SEED)
    )
    loader = DataLoader(val_set, batch_size=1, shuffle=False)

    models = {
        "Supervised_UNet": load_model(ROOT / "models/generator_best.pth"),
        "GAN": load_model(ROOT / "models/generator_gan_best.pth"),
    }

    rows = []
    sums = {name: {"mae": 0.0, "psnr": 0.0} for name in models}

    with torch.no_grad():
        for idx, (cloudy, clear) in enumerate(loader):
            cloudy, clear = cloudy.to(DEVICE), clear.to(DEVICE)
            filename = dataset.pairs[val_set.indices[idx]][0].name

            for name, model in models.items():
                pred = model(cloudy).clamp(-1, 1)
                mae = F.l1_loss(pred, clear).item()
                mse = F.mse_loss(pred, clear).item()
                psnr = 99.0 if mse == 0 else 10.0 * torch.log10(
                    torch.tensor(4.0 / mse)
                ).item()

                sums[name]["mae"] += mae
                sums[name]["psnr"] += psnr
                rows.append([filename, name, mae, psnr])

    count = len(loader)
    print(f"Validation images: {count}")
    for name in models:
        print(
            f"{name}: mean MAE={sums[name]['mae']/count:.6f}, "
            f"mean PSNR={sums[name]['psnr']/count:.3f} dB"
        )

    out = ROOT / "outputs/validation_metrics.csv"
    with out.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["filename", "model", "mae", "psnr_db"])
        writer.writerows(rows)
    print(f"Saved per-image metrics: {out}")


if __name__ == "__main__":
    main()
