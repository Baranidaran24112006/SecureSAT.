
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch
from torch.utils.data import random_split
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

MODELS = {
    "L1 baseline": ROOT / "models/generator_reflectance_best.pth",
    "Edge loss": ROOT / "models/generator_reflectance_edge_best.pth",
}


def image_metrics(prediction, target):
    prediction = prediction.detach().cpu().float().clamp(-1, 1)
    target = target.detach().cpu().float().clamp(-1, 1)

    pred = ((prediction + 1) / 2).numpy()
    ref = ((target + 1) / 2).numpy()

    mae = float(np.mean(np.abs(pred - ref)))
    psnr = float(peak_signal_noise_ratio(ref, pred, data_range=1.0))

    pred_rgb = np.transpose(pred, (1, 2, 0))
    ref_rgb = np.transpose(ref, (1, 2, 0))

    ssim = np.mean([
        structural_similarity(
            ref_rgb[:, :, c],
            pred_rgb[:, :, c],
            data_range=1.0,
        )
        for c in range(3)
    ])

    dx = np.diff(pred, axis=2)
    dy = np.diff(pred, axis=1)
    sharpness = float((np.abs(dx).mean() + np.abs(dy).mean()) / 2)

    return mae, psnr, float(ssim), sharpness


def main():
    dataset = SatelliteReflectanceDataset(
        cloudy_dir=str(ROOT / "data/raw/cloudy"),
        clear_dir=str(ROOT / "data/raw/clear"),
        size=256,
    )

    val_size = max(1, int(len(dataset) * 0.2))
    train_size = len(dataset) - val_size

    _, val_set = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(42),
    )

    print("Validation samples:", len(val_set))
    print("Device:", DEVICE)

    all_rows = []

    for model_name, checkpoint in MODELS.items():
        if not checkpoint.exists():
            raise FileNotFoundError(checkpoint)

        model = UNetGenerator(features=16).to(DEVICE)
        model.load_state_dict(
            torch.load(checkpoint, map_location=DEVICE, weights_only=True)
        )
        model.eval()

        for index in val_set.indices:
            cloudy, clear = dataset[index]

            with torch.inference_mode():
                prediction = model(
                    cloudy.unsqueeze(0).to(DEVICE)
                ).squeeze(0).cpu()

            mae, psnr, ssim, sharpness = image_metrics(prediction, clear)

            all_rows.append({
                "model": model_name,
                "dataset_index": index,
                "mae": mae,
                "psnr": psnr,
                "ssim": ssim,
                "sharpness": sharpness,
            })

        print("Evaluated:", model_name)

    results = pd.DataFrame(all_rows)
    output_csv = ROOT / "outputs/reflectance_model_comparison.csv"
    results.to_csv(output_csv, index=False)

    summary = results.groupby("model")[
        ["mae", "psnr", "ssim", "sharpness"]
    ].mean()

    print("\nMean metrics across the same validation images")
    print(summary.round(6).to_string())
    print(f"\nDetailed results: {output_csv}")


if __name__ == "__main__":
    main()
