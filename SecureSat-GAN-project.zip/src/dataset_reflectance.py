from pathlib import Path

import numpy as np
import rasterio
import torch
from torch.utils.data import Dataset


class SatelliteReflectanceDataset(Dataset):
    def __init__(
        self,
        cloudy_dir="data/raw/cloudy",
        clear_dir="data/raw/clear",
        size=256,
        scale=10000.0,
    ):
        self.cloudy_dir = Path(cloudy_dir)
        self.clear_dir = Path(clear_dir)
        self.size = size
        self.scale = scale

        self.pairs = []
        for cloudy in sorted(self.cloudy_dir.glob("*.tif")):
            clear = self.clear_dir / cloudy.name
            if clear.is_file():
                self.pairs.append((cloudy, clear))

        if not self.pairs:
            raise ValueError("No matching cloudy/clear TIFF pairs found.")

    def _load_rgb(self, path):
        with rasterio.open(path) as src:
            image = src.read([4, 3, 2]).astype(np.float32)

        # Keep floating-point reflectance values; do not quantize to uint8.
        image = np.clip(image / self.scale, 0.0, 1.0)
        image = image * 2.0 - 1.0

        return torch.from_numpy(image.copy())

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, index):
        cloudy_path, clear_path = self.pairs[index]
        return self._load_rgb(cloudy_path), self._load_rgb(clear_path)


if __name__ == "__main__":
    dataset = SatelliteReflectanceDataset()
    cloudy, clear = dataset[0]

    print("Matched pairs:", len(dataset))
    print("Cloudy tensor:", tuple(cloudy.shape))
    print("Clear tensor:", tuple(clear.shape))
    print("Cloudy range:", cloudy.min().item(), cloudy.max().item())
    print("Clear range:", clear.min().item(), clear.max().item())
    print("Tensor dtype:", cloudy.dtype)
