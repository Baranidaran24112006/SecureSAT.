"""Explicit entry point for the paired cloudy-to-clear conditional GAN."""
try:  # Support both `python src/train_conditional_gan.py` and module invocation.
    from .train_gan import main
except ImportError:
    from train_gan import main


if __name__ == "__main__":
    main()
