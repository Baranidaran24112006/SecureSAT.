"""Run the paired conditional-GAN U-Net generator on one cloudy GeoTIFF."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch

from backend.services.raster import export_geotiff, read_raster
from generator import UNetGenerator

def main() -> None:
    parser = argparse.ArgumentParser(description="Translate one cloudy TIFF with a trained paired cGAN generator.")
    parser.add_argument("--input", type=Path, required=True, help="Input cloudy TIFF.")
    parser.add_argument("--checkpoint", type=Path, default=ROOT / "models/generator_gan_best.pth")
    parser.add_argument("--output", type=Path, default=None, help="Output path; defaults to restored_<input-name>.")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    if not args.input.is_file():
        parser.error(f"Input file does not exist: {args.input}")
    if not args.checkpoint.is_file():
        parser.error(f"Checkpoint does not exist: {args.checkpoint}. Train the conditional GAN first.")
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        if args.device == "cuda" and not torch.cuda.is_available():
            parser.error("CUDA was requested but is not available.")
        device = torch.device(args.device)

    rgb, profile, invalid = read_raster(args.input.read_bytes())
    if invalid.any():
        parser.error(f"Input contains {int(invalid.sum())} masked RGB pixels.")
    # Match src/dataset.py's 8-bit RGB quantization before mapping to [-1,1].
    quantized = (np.moveaxis(rgb, 0, -1) * 255.0).astype(np.uint8).astype(np.float32) / 255.0
    tensor = torch.from_numpy(np.moveaxis(quantized * 2.0 - 1.0, -1, 0).copy()).unsqueeze(0).to(device)
    generator = UNetGenerator(features=16).to(device)
    generator.load_state_dict(torch.load(args.checkpoint, map_location=device, weights_only=True), strict=True)
    generator.eval()
    with torch.inference_mode():
        prediction = ((generator(tensor).squeeze(0).cpu().numpy() + 1.0) / 2.0).clip(0.0, 1.0)
    output = args.output or args.input.with_name(f"restored_{args.input.stem}.tif")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(export_geotiff(prediction, profile))
    print(f"Saved 3-band conditional-GAN estimate: {output}")
    print(f"Device: {device}; source CRS: {profile.get('crs') or 'not defined'}")
    print("The translated image is a model estimate, not verified ground truth.")


if __name__ == "__main__":
    main()
