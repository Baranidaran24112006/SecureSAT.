from pathlib import Path
import csv
import sys

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
EPOCHS = 30
BATCH_SIZE = 2
LR = 0.0001
PATIENCE = 5
SEED = 42


def main():
    torch.manual_seed(SEED)

    dataset = SatelliteReflectanceDataset(
        cloudy_dir=str(ROOT / "data/raw/cloudy"),
        clear_dir=str(ROOT / "data/raw/clear"),
        size=256,
    )

    n_val = max(1, int(len(dataset) * 0.2))
    n_train = len(dataset) - n_val

    train_set, val_set = random_split(
        dataset,
        [n_train, n_val],
        generator=torch.Generator().manual_seed(SEED),
    )

    train_loader = DataLoader(
        train_set, batch_size=BATCH_SIZE, shuffle=True, num_workers=0
    )
    val_loader = DataLoader(
        val_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=0
    )

    model = UNetGenerator(features=16).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = nn.L1Loss()

    models_dir = ROOT / "models"
    outputs_dir = ROOT / "outputs"
    models_dir.mkdir(exist_ok=True)
    outputs_dir.mkdir(exist_ok=True)

    best_path = models_dir / "generator_reflectance_best.pth"
    latest_path = models_dir / "generator_reflectance_latest.pth"
    history_path = outputs_dir / "reflectance_training_history.csv"

    best_val = float("inf")
    no_improve = 0

    with history_path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["epoch", "train_l1", "val_l1"])

        print(f"Device: {DEVICE}")
        print(f"Training pairs: {len(train_set)}")
        print(f"Validation pairs: {len(val_set)}")

        for epoch in range(1, EPOCHS + 1):
            model.train()
            train_total = 0.0

            for cloudy, clear in train_loader:
                cloudy = cloudy.to(DEVICE)
                clear = clear.to(DEVICE)

                pred = model(cloudy)
                loss = criterion(pred, clear)

                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
                train_total += loss.item()

            train_loss = train_total / len(train_loader)

            model.eval()
            val_total = 0.0
            with torch.no_grad():
                for cloudy, clear in val_loader:
                    pred = model(cloudy.to(DEVICE))
                    val_total += criterion(pred, clear.to(DEVICE)).item()

            val_loss = val_total / len(val_loader)

            torch.save(model.state_dict(), latest_path)

            if val_loss < best_val:
                best_val = val_loss
                no_improve = 0
                torch.save(model.state_dict(), best_path)
                status = "best saved"
            else:
                no_improve += 1
                status = f"no improvement {no_improve}/{PATIENCE}"

            writer.writerow([epoch, train_loss, val_loss])
            f.flush()

            print(
                f"Epoch {epoch:02d}/{EPOCHS} | "
                f"train L1={train_loss:.6f} | "
                f"val L1={val_loss:.6f} | {status}",
                flush=True,
            )

            if no_improve >= PATIENCE:
                print("Early stopping: validation loss stopped improving.")
                break

    print(f"Best checkpoint: {best_path}")
    print(f"Training history: {history_path}")


if __name__ == "__main__":
    main()
