from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset import SatelliteCloudDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def display_stretch(tensor):
    image = tensor.detach().cpu().clamp(-1, 1).permute(1, 2, 0).numpy()
    image = (image + 1.0) / 2.0
    low = np.percentile(image, 2, axis=(0, 1), keepdims=True)
    high = np.percentile(image, 98, axis=(0, 1), keepdims=True)
    return np.clip((image - low) / np.maximum(high - low, 1e-6), 0, 1)


def main():
    dataset = SatelliteCloudDataset()
    generator = UNetGenerator(features=16).to(DEVICE)

    checkpoint = ROOT / "models/generator_gan_best.pth"
    generator.load_state_dict(
        torch.load(checkpoint, map_location=DEVICE, weights_only=True)
    )
    generator.eval()

    # Use the same sample as the previous comparison.
    cloudy, clear = dataset[0]

    with torch.no_grad():
        generated = generator(cloudy.unsqueeze(0).to(DEVICE))[0].cpu()

    input_mae = torch.mean(torch.abs(cloudy - clear)).item()
    output_mae = torch.mean(torch.abs(generated - clear)).item()

    print(f"Device: {DEVICE}")
    print(f"Sample: {dataset.pairs[0][0].name}")
    print(f"Input MAE: {input_mae:.6f}")
    print(f"GAN output MAE: {output_mae:.6f}")

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, tensor, title in zip(
        axes,
        [cloudy, clear, generated],
        ["Cloudy Input", "Clear Reference", "GAN Output"],
    ):
        ax.imshow(display_stretch(tensor))
        ax.set_title(title)
        ax.axis("off")

    fig.tight_layout()
    output = ROOT / "outputs/gan_cloud_removal_comparison.png"
    fig.savefig(output, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved comparison: {output}")


if __name__ == "__main__":
    main()
