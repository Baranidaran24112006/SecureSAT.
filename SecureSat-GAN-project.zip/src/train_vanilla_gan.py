"""Train an unconditional Vanilla GAN on clear RGB satellite patches.

This is a generative example: it samples new images from random noise and is
not a cloud-removal model. Run from the project root with python src/train_vanilla_gan.py.
"""
from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from torch import nn
from torch.utils.data import DataLoader, Subset, random_split

from gan_data import SatelliteImageDataset
from gan_models import VanillaDiscriminator, VanillaGenerator

ROOT = Path(__file__).resolve().parents[1]


def choose_device(value: str) -> torch.device:
    if value == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if value == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available.")
    return torch.device(value)


def save_grid(images: torch.Tensor, output: Path) -> None:
    images = ((images.detach().cpu().clamp(-1, 1) + 1) / 2).permute(0, 2, 3, 1).numpy()
    columns = min(4, len(images))
    rows = (len(images) + columns - 1) // columns
    canvas = Image.new("RGB", (columns * 256, rows * 256), "black")
    for index, image in enumerate(images):
        display = np.empty_like(image)
        for channel in range(3):
            low, high = np.percentile(image[..., channel], [2, 98])
            display[..., channel] = np.clip((image[..., channel] - low) / max(float(high - low), 1e-6), 0, 1)
        image = Image.fromarray((display * 255).round().astype(np.uint8), "RGB")
        canvas.paste(image, ((index % columns) * 256, (index // columns) * 256))
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)


def save_validation_comparison(real: torch.Tensor, generated: torch.Tensor, output: Path) -> None:
    """Save held-out clear patches beside generated samples for visual review."""
    tiles = [*real[:4].detach().cpu(), *generated[:4].detach().cpu()]
    labels = ["Held-out clear reference"] * min(4, len(real)) + ["Vanilla GAN sample"] * min(4, len(generated))
    canvas = Image.new("RGB", (4 * 256, 2 * 276), "#151915")
    draw = ImageDraw.Draw(canvas)
    for index, tensor in enumerate(tiles):
        image = ((tensor.clamp(-1, 1) + 1) / 2).permute(1, 2, 0).numpy()
        display = np.empty_like(image)
        for channel in range(3):
            low, high = np.percentile(image[..., channel], [2, 98])
            display[..., channel] = np.clip((image[..., channel] - low) / max(float(high - low), 1e-6), 0, 1)
        tile = Image.fromarray((display * 255).round().astype(np.uint8), "RGB")
        x, y = (index % 4) * 256, (index // 4) * 276
        draw.text((x + 6, y + 5), labels[index], fill="white")
        canvas.paste(tile, (x, y + 20))
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)


def initialize_weights(module: nn.Module) -> None:
    weight = getattr(module, "weight_orig", getattr(module, "weight", None))
    if isinstance(module, (nn.Conv2d, nn.ConvTranspose2d)) and weight is not None:
        nn.init.normal_(weight, 0.0, 0.02)
    elif isinstance(module, nn.BatchNorm2d):
        nn.init.normal_(module.weight, 1.0, 0.02)
        nn.init.zeros_(module.bias)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train an unconditional Vanilla GAN on clear satellite patches.")
    parser.add_argument("--data", type=Path, default=ROOT / "data/raw/clear", help="Folder of clear 13-band TIFFs.")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--latent-dim", type=int, default=100)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--validation-fraction", type=float, default=0.1,
                        help="Held-out clear image fraction shown beside generated previews.")
    parser.add_argument("--resume", action="store_true",
                        help="Continue from models/vanilla_gan_v2.pth; --epochs is the number of additional epochs.")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1:
        parser.error("--epochs and --batch-size must be positive")

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = choose_device(args.device)
    if not 0.05 <= args.validation_fraction < 0.5:
        parser.error("--validation-fraction must be between 0.05 and 0.5")
    dataset = SatelliteImageDataset(args.data)
    n_val = max(4, int(len(dataset) * args.validation_fraction)) if len(dataset) >= 8 else max(1, len(dataset) // 5)
    n_train = len(dataset) - n_val
    if n_train < 1:
        parser.error("Need at least two clear images for a training/validation split.")
    train_set, val_subset = random_split(dataset, [n_train, n_val], generator=torch.Generator().manual_seed(args.seed))
    val_set = Subset(SatelliteImageDataset(args.data, augment=False), val_subset.indices)
    loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_set, batch_size=min(4, n_val), shuffle=False, num_workers=0)
    generator = VanillaGenerator(args.latent_dim, args.base_channels).to(device)
    discriminator = VanillaDiscriminator(args.base_channels).to(device)
    generator.apply(initialize_weights)
    discriminator.apply(initialize_weights)
    optimizer_g = torch.optim.Adam(generator.parameters(), lr=2e-4, betas=(0.0, 0.9))
    optimizer_d = torch.optim.Adam(discriminator.parameters(), lr=2e-4, betas=(0.0, 0.9))
    fixed_noise = torch.randn(16, args.latent_dim, device=device)
    checkpoint = ROOT / "models/vanilla_gan_v2.pth"
    samples = ROOT / "outputs/vanilla_gan"
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    samples.mkdir(parents=True, exist_ok=True)
    history = samples / "training_history.csv"
    start_epoch = 1
    if args.resume:
        if not checkpoint.is_file():
            parser.error(f"Cannot resume: checkpoint not found at {checkpoint}")
        state = torch.load(checkpoint, map_location=device, weights_only=True)
        if state.get("architecture_version") != 2 or state.get("latent_dim") != args.latent_dim or state.get("base_channels") != args.base_channels:
            parser.error("Resume checkpoint architecture does not match --latent-dim/--base-channels.")
        generator.load_state_dict(state["generator"], strict=True)
        discriminator.load_state_dict(state["discriminator"], strict=True)
        start_epoch = int(state.get("epoch", 0)) + 1
        if "optimizer_g" in state and "optimizer_d" in state:
            optimizer_g.load_state_dict(state["optimizer_g"])
            optimizer_d.load_state_dict(state["optimizer_d"])
        else:
            print("Resuming weights from the existing checkpoint; optimizer history was not saved and will restart.", flush=True)
        if not history.is_file():
            with history.open("w", newline="") as stream:
                csv.writer(stream).writerow(["epoch", "generator_loss", "discriminator_loss", "heldout_real_score", "generated_score"])
        print(f"Resuming from epoch {start_epoch - 1}; running {args.epochs} additional epochs.", flush=True)
    else:
        with history.open("w", newline="") as stream:
            csv.writer(stream).writerow(["epoch", "generator_loss", "discriminator_loss", "heldout_real_score", "generated_score"])
    heldout_real = next(iter(val_loader))[:4].to(device)

    print(f"Vanilla GAN | device={device} | training images={len(train_set)} | held-out clear images={len(val_set)}")
    print("Each epoch saves a held-out-real vs generated comparison. GAN losses do not measure image realism.")
    for epoch in range(start_epoch, start_epoch + args.epochs):
        generator.train()
        discriminator.train()
        sum_g = sum_d = 0.0
        progress_interval = max(1, len(loader) // 10)
        for step, real in enumerate(loader, start=1):
            real = real.to(device)
            batch = real.shape[0]
            noise = torch.randn(batch, args.latent_dim, device=device)
            fake = generator(noise)
            real_logits = discriminator(real)
            fake_logits = discriminator(fake.detach())
            # Hinge loss and spectral normalization reduce discriminator
            # domination and mode collapse seen with the earlier BCE setup.
            loss_d = torch.relu(1.0 - real_logits).mean() + torch.relu(1.0 + fake_logits).mean()
            optimizer_d.zero_grad(set_to_none=True)
            loss_d.backward()
            optimizer_d.step()

            noise = torch.randn(batch, args.latent_dim, device=device)
            generated = generator(noise)
            for parameter in discriminator.parameters():
                parameter.requires_grad_(False)
            loss_g = -discriminator(generated).mean()
            optimizer_g.zero_grad(set_to_none=True)
            loss_g.backward()
            optimizer_g.step()
            for parameter in discriminator.parameters():
                parameter.requires_grad_(True)
            sum_g += float(loss_g.detach())
            sum_d += float(loss_d.detach())
            if step % progress_interval == 0 or step == len(loader):
                print(f"\rEpoch {epoch:03}/{args.epochs} | batch {step}/{len(loader)}", end="", flush=True)

        generator.eval()
        discriminator.eval()
        with torch.inference_mode():
            generated = generator(fixed_noise)
            real_score = float(discriminator(heldout_real).mean().cpu())
            fake_score = float(discriminator(generated).mean().cpu())
        save_validation_comparison(heldout_real, generated, samples / f"epoch_{epoch:03}.png")
        torch.save({"generator": generator.state_dict(), "discriminator": discriminator.state_dict(),
                    "latent_dim": args.latent_dim, "base_channels": args.base_channels,
                    "epoch": epoch, "objective": "hinge + spectral normalization",
                    "architecture_version": 2, "training_images": len(train_set),
                    "validation_images": len(val_set), "optimizer_g": optimizer_g.state_dict(),
                    "optimizer_d": optimizer_d.state_dict()}, checkpoint)
        with history.open("a", newline="") as stream:
            csv.writer(stream).writerow([epoch, sum_g / len(loader), sum_d / len(loader), real_score, fake_score])
        print(f"\nEpoch {epoch:03} | G={sum_g / len(loader):.4f} | D={sum_d / len(loader):.4f} | held-out D(real)={real_score:.3f}, D(fake)={fake_score:.3f} | preview={samples / f'epoch_{epoch:03}.png'}", flush=True)

    print(f"Generated image grids: {samples}")
    print("This model generates samples; it does not restore a supplied cloudy image.")


if __name__ == "__main__":
    main()
