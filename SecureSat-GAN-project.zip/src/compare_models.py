from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset import SatelliteCloudDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def display_rgb(t):
    # Consistent display mapping for all images.
    image = ((t.detach().cpu().clamp(-1, 1) + 1) / 2)
    image = image.permute(1, 2, 0).numpy()
    low = np.percentile(image, 2, axis=(0, 1), keepdims=True)
    high = np.percentile(image, 98, axis=(0, 1), keepdims=True)
    return np.clip((image - low) / np.maximum(high - low, 1e-6), 0, 1)


def load_model(checkpoint):
    model = UNetGenerator(features=16).to(DEVICE)
    model.load_state_dict(
        torch.load(ROOT / checkpoint, map_location=DEVICE, weights_only=True)
    )
    model.eval()
    return model


def main():
    dataset = SatelliteCloudDataset()
    cloudy, clear = dataset[0]

    supervised = load_model("models/generator_best.pth")
    gan = load_model("models/generator_gan_best.pth")

    with torch.no_grad():
        x = cloudy.unsqueeze(0).to(DEVICE)
        supervised_out = supervised(x)[0].cpu()
        gan_out = gan(x)[0].cpu()

    for name, out in [
        ("Supervised U-Net", supervised_out),
        ("GAN", gan_out),
    ]:
        mae = torch.mean(torch.abs(out - clear)).item()
        print(f"{name} MAE: {mae:.6f}")

    items = [
        (cloudy, "Cloudy Input"),
        (clear, "Clear Reference"),
        (supervised_out, "Supervised U-Net"),
        (gan_out, "GAN Output"),
    ]

    fig, axes = plt.subplots(1, 4, figsize=(18, 5))
    for ax, (tensor, title) in zip(axes, items):
        ax.imshow(display_rgb(tensor))
        ax.set_title(title)
        ax.axis("off")

    fig.tight_layout()
    output = ROOT / "outputs/model_comparison.png"
    fig.savefig(output, dpi=160, bbox_inches="tight")
    print(f"Saved: {output}")


if __name__ == "__main__":
    main()
