
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dataset_reflectance import SatelliteReflectanceDataset
from generator import UNetGenerator

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_model(checkpoint):
    model = UNetGenerator(features=16).to(DEVICE)
    model.load_state_dict(
        torch.load(checkpoint, map_location=DEVICE, weights_only=True)
    )
    model.eval()
    return model


def to_rgb(tensor):
    return (
        tensor.detach().cpu().float().clamp(-1, 1)
        .add(1).div(2)
        .permute(1, 2, 0).numpy()
    )


def main():
    dataset = SatelliteReflectanceDataset(
        cloudy_dir=str(ROOT / "data/raw/cloudy"),
        clear_dir=str(ROOT / "data/raw/clear"),
        size=256,
    )

    val_size = max(1, int(len(dataset) * 0.2))
    train_size = len(dataset) - val_size

    from torch.utils.data import random_split

    _, val_set = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(42),
    )

    baseline = load_model(
        ROOT / "models/generator_reflectance_best.pth"
    )
    edge_model = load_model(
        ROOT / "models/generator_reflectance_edge_best.pth"
    )

    output_dir = ROOT / "outputs"
    output_dir.mkdir(exist_ok=True)

    indices = val_set.indices[:8]

    for index in indices:
        cloudy, clear = dataset[index]

        with torch.inference_mode():
            baseline_pred = baseline(
                cloudy.unsqueeze(0).to(DEVICE)
            ).squeeze(0).cpu()

            edge_pred = edge_model(
                cloudy.unsqueeze(0).to(DEVICE)
            ).squeeze(0).cpu()

        images = [
            (to_rgb(cloudy), "Cloudy Input"),
            (to_rgb(clear), "Clear Reference"),
            (to_rgb(baseline_pred), "L1 Baseline"),
            (to_rgb(edge_pred), "Edge Loss"),
        ]

        fig, axes = plt.subplots(1, 4, figsize=(16, 4))

        for ax, (image, title) in zip(axes, images):
            ax.imshow(np.clip(image, 0, 1))
            ax.set_title(title)
            ax.axis("off")

        fig.suptitle(f"Validation sample index: {index}")
        fig.tight_layout()

        filename = output_dir / f"model_comparison_{index}.png"
        fig.savefig(filename, dpi=150, bbox_inches="tight")
        plt.close(fig)

        print(f"Saved: {filename}")

    print("\nVisual comparisons completed.")


if __name__ == "__main__":
    main()
