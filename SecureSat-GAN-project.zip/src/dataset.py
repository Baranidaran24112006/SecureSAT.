
from pathlib import Path

import numpy as np
import rasterio
import torch
from torch.utils.data import Dataset
from PIL import Image


class SatelliteCloudDataset(Dataset):
    def __init__(
        self,
        cloudy_dir="data/raw/cloudy",
        clear_dir="data/raw/clear",
        size=256,
    ):
        self.cloudy_dir = Path(cloudy_dir)
        self.clear_dir = Path(clear_dir)
        self.size = size

        self.pairs = []

        # Preserve the original six pairs.
        for name in sorted(
            p.name for p in self.cloudy_dir.glob("pair_*.tif")
        ):
            cloudy = self.cloudy_dir / name
            clear = self.clear_dir / name

            if clear.is_file():
                self.pairs.append((cloudy, clear))

        # Add newly extracted patches using their original patch IDs.
        for cloudy in sorted(self.cloudy_dir.glob("patch_*.tif")):
            clear = self.clear_dir / cloudy.name

            if clear.is_file():
                self.pairs.append((cloudy, clear))

        if not self.pairs:
            raise ValueError("No matching cloudy/clear TIFF pairs found.")

    def _load_rgb(self, path):
        with rasterio.open(path) as src:
            if src.count < 4:
                raise ValueError(
                    f"Expected at least 4 bands in {path}; found {src.count}"
                )

            image = src.read([4, 3, 2]).astype(np.float32)

        image = np.clip(image / 10000.0, 0.0, 1.0)
        image = np.moveaxis(image, 0, -1)

        image = Image.fromarray((image * 255).astype(np.uint8))
        image = image.resize(
            (self.size, self.size),
            Image.Resampling.BILINEAR,
        )

        image = np.asarray(image, dtype=np.float32) / 255.0
        image = image * 2.0 - 1.0

        return torch.from_numpy(
            np.moveaxis(image, -1, 0).copy()
        )

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, index):
        cloudy_path, clear_path = self.pairs[index]

        return self._load_rgb(cloudy_path), self._load_rgb(clear_path)


if __name__ == "__main__":
    dataset = SatelliteCloudDataset()

    print("Matching pairs:", len(dataset))

    for cloudy_path, clear_path in dataset.pairs[:10]:
        print(f"{cloudy_path.name} <-> {clear_path.name}")

    cloudy, clear = dataset[0]

    print("Cloudy tensor:", tuple(cloudy.shape))
    print("Clear tensor:", tuple(clear.shape))
    print("Cloudy range:", cloudy.min().item(), cloudy.max().item())
    print("Clear range:", clear.min().item(), clear.max().item())
