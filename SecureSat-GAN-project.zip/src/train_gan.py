"""Train the paired conditional GAN (cGAN) cloudy-to-clear translator."""
from pathlib import Path
import argparse
import csv
import random

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split

try:
    from .dataset import SatelliteCloudDataset
    from .generator import UNetGenerator
    from .discriminator import PatchGANDiscriminator
except ImportError:
    from dataset import SatelliteCloudDataset
    from generator import UNetGenerator
    from discriminator import PatchGANDiscriminator

ROOT = Path(__file__).resolve().parent.parent
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

EPOCHS = 20
BATCH_SIZE = 1
LR_G = 0.0001
LR_D = 0.0001
LAMBDA_L1 = 100.0
SEED = 42

torch.manual_seed(SEED)
random.seed(SEED)


def main():
    parser = argparse.ArgumentParser(description="Train a paired cloudy-to-clear conditional GAN.")
    parser.add_argument("--cloudy", type=Path, default=ROOT / "data/raw/cloudy")
    parser.add_argument("--clear", type=Path, default=ROOT / "data/raw/clear")
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1:
        parser.error("--epochs and --batch-size must be positive")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA was requested but is not available.")
    torch.manual_seed(SEED)

    dataset = SatelliteCloudDataset(
        cloudy_dir=str(args.cloudy),
        clear_dir=str(args.clear),
        size=256,
    )

    val_size = max(1, int(0.2 * len(dataset)))
    train_size = len(dataset) - val_size
    train_set, val_set = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(SEED),
    )

    train_loader = DataLoader(
        train_set, batch_size=args.batch_size, shuffle=True, num_workers=0
    )
    val_loader = DataLoader(
        val_set, batch_size=args.batch_size, shuffle=False, num_workers=0
    )

    generator = UNetGenerator(features=16).to(device)
    discriminator = PatchGANDiscriminator(features=16).to(device)

    opt_g = torch.optim.Adam(
        generator.parameters(), lr=LR_G, betas=(0.5, 0.999)
    )
    opt_d = torch.optim.Adam(
        discriminator.parameters(), lr=LR_D, betas=(0.5, 0.999)
    )

    l1_loss = nn.L1Loss()
    gan_loss = nn.BCEWithLogitsLoss()

    models = ROOT / "models"
    outputs = ROOT / "outputs"
    models.mkdir(exist_ok=True)
    outputs.mkdir(exist_ok=True)

    best_path = models / "generator_gan_best.pth"
    latest_path = models / "generator_gan_latest.pth"
    disc_path = models / "discriminator_gan_latest.pth"
    history_path = outputs / "gan_training_history.csv"

    best_val = float("inf")

    with history_path.open("w", newline="") as f:
        csv.writer(f).writerow(
            ["epoch", "generator_loss", "discriminator_loss",
             "train_l1", "val_l1"]
        )

    print(f"Device: {device}")
    print(f"Training pairs: {len(train_set)}")
    print(f"Validation pairs: {len(val_set)}")
    print(f"Epochs: {args.epochs}")

    for epoch in range(1, args.epochs + 1):
        generator.train()
        discriminator.train()

        total_g = total_d = total_l1 = 0.0

        for step, (cloudy, clear) in enumerate(train_loader, 1):
            cloudy = cloudy.to(device)
            clear = clear.to(device)

            # Train discriminator on real and generated pairs.
            with torch.no_grad():
                fake_for_d = generator(cloudy)

            real_logits = discriminator(cloudy, clear)
            fake_logits = discriminator(cloudy, fake_for_d)

            real_labels = torch.ones_like(real_logits)
            fake_labels = torch.zeros_like(fake_logits)

            d_loss = 0.5 * (
                gan_loss(real_logits, real_labels)
                + gan_loss(fake_logits, fake_labels)
            )

            opt_d.zero_grad(set_to_none=True)
            d_loss.backward()
            opt_d.step()

            # Train generator to reconstruct clear images and fool D.
            generated = generator(cloudy)
            fake_logits = discriminator(cloudy, generated)

            reconstruction = l1_loss(generated, clear)
            adversarial = gan_loss(
                fake_logits, torch.ones_like(fake_logits)
            )
            g_loss = adversarial + LAMBDA_L1 * reconstruction

            opt_g.zero_grad(set_to_none=True)
            g_loss.backward()
            opt_g.step()

            total_g += g_loss.item()
            total_d += d_loss.item()
            total_l1 += reconstruction.item()

            if step % 50 == 0 or step == len(train_loader):
                print(
                    f"\rEpoch {epoch}/{args.epochs} "
                    f"batch {step}/{len(train_loader)} "
                    f"G={g_loss.item():.3f} D={d_loss.item():.3f}",
                    end="", flush=True
                )

        generator.eval()
        val_total = 0.0

        with torch.no_grad():
            for cloudy, clear in val_loader:
                cloudy, clear = cloudy.to(device), clear.to(device)
                generated = generator(cloudy)
                val_total += l1_loss(generated, clear).item()

        val_l1 = val_total / len(val_loader)
        avg_g = total_g / len(train_loader)
        avg_d = total_d / len(train_loader)
        avg_l1 = total_l1 / len(train_loader)

        print(
            f"\nEpoch {epoch}: G={avg_g:.4f}, D={avg_d:.4f}, "
            f"train L1={avg_l1:.5f}, val L1={val_l1:.5f}"
        )

        torch.save(generator.state_dict(), latest_path)
        torch.save(discriminator.state_dict(), disc_path)

        if val_l1 < best_val:
            best_val = val_l1
            torch.save(generator.state_dict(), best_path)
            print(f"Saved best GAN generator (val L1={best_val:.5f})")

        with history_path.open("a", newline="") as f:
            csv.writer(f).writerow(
                [epoch, avg_g, avg_d, avg_l1, val_l1]
            )

    print("\nConditional GAN (cGAN) training completed.")
    print(f"Best generator: {best_path}")
    print(f"Latest generator: {latest_path}")
    print(f"Discriminator: {disc_path}")
    print(f"History: {history_path}")


if __name__ == "__main__":
    main()
